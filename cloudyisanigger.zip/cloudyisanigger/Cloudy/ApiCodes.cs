﻿using System;

namespace Cloudy
{
	// Token: 0x02000004 RID: 4
	internal class ApiCodes
	{
		// Token: 0x04000006 RID: 6
		public const int SC_RESTORE = 61728;

		// Token: 0x04000007 RID: 7
		public const int SC_MINIMIZE = 61472;

		// Token: 0x04000008 RID: 8
		public const int WM_SYSCOMMAND = 274;
	}
}
