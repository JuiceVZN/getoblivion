﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Cloudy.Properties
{
	// Token: 0x02000006 RID: 6
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x060000ED RID: 237 RVA: 0x0000B1E9 File Offset: 0x000093E9
		internal Resources()
		{
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x060000EE RID: 238 RVA: 0x0000B1F4 File Offset: 0x000093F4
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager temp = new ResourceManager("Cloudy.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = temp;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x060000EF RID: 239 RVA: 0x0000B23C File Offset: 0x0000943C
		// (set) Token: 0x060000F0 RID: 240 RVA: 0x0000B253 File Offset: 0x00009453
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x040000AB RID: 171
		private static ResourceManager resourceMan;

		// Token: 0x040000AC RID: 172
		private static CultureInfo resourceCulture;
	}
}
