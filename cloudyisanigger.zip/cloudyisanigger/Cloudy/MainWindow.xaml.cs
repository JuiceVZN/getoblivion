﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shell;
using System.Windows.Threading;
using CefSharp;
using CefSharp.Wpf;
using Cloudy.Classes;
using Cloudy.Controls;
using CloudyApi;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;

namespace Cloudy
{
	// Token: 0x02000005 RID: 5
	public partial class MainWindow : Window, IStyleConnector
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000011 RID: 17 RVA: 0x000024E4 File Offset: 0x000006E4
		// (set) Token: 0x06000012 RID: 18 RVA: 0x000024EC File Offset: 0x000006EC
		public bool openLogs { get; set; } = true;

		// Token: 0x06000013 RID: 19
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int wMsg, IntPtr wParam, IntPtr lParam);

		// Token: 0x06000014 RID: 20 RVA: 0x000024F8 File Offset: 0x000006F8
		private IntPtr WindowProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			bool flag = msg == 274;
			if (flag)
			{
				bool flag2 = wParam.ToInt32() == 61472;
				if (flag2)
				{
					base.WindowStyle = WindowStyle.SingleBorderWindow;
					base.WindowState = WindowState.Minimized;
					handled = true;
				}
				else
				{
					bool flag3 = wParam.ToInt32() == 61728;
					if (flag3)
					{
						base.WindowState = WindowState.Normal;
						base.WindowStyle = WindowStyle.SingleBorderWindow;
						handled = true;
					}
				}
			}
			return IntPtr.Zero;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002570 File Offset: 0x00000770
		public MainWindow()
		{
			this.InitializeComponent();
			this.Initialize();
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002630 File Offset: 0x00000830
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			this.hWnd = new WindowInteropHelper(this).Handle;
			HwndSource.FromHwnd(this.hWnd).AddHook(new HwndSourceHook(this.WindowProc));
			base.Focus();
			this.Home.Visibility = Visibility.Visible;
			this.AnimatePosition((TranslateTransform)this.Home.RenderTransform, 50.0, 0.0, 0.5);
			this.AnimateOpacity(this.Home, 0.0, 1.0, 0.5);
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000026DC File Offset: 0x000008DC
		private void Window_Closing(object sender, CancelEventArgs e)
		{
			bool flag = !this.isClose;
			if (flag)
			{
				MessageBoxResult result = System.Windows.MessageBox.Show("Are you sure you want to close?", base.Title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
				bool flag2 = result != MessageBoxResult.Yes;
				if (flag2)
				{
					e.Cancel = true;
				}
			}
			else
			{
				this.isClose = false;
			}
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002730 File Offset: 0x00000930
		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			for (DependencyObject clickedElement = (DependencyObject)e.OriginalSource; clickedElement != null; clickedElement = VisualTreeHelper.GetParent(clickedElement))
			{
				bool flag = clickedElement is System.Windows.Controls.TextBox;
				if (flag)
				{
					return;
				}
				bool flag2 = clickedElement is Visual || clickedElement is Visual3D;
				if (!flag2)
				{
					break;
				}
			}
			FocusManager.SetFocusedElement(this, this);
			Keyboard.ClearFocus();
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000279C File Offset: 0x0000099C
		private void Initialize()
		{
			this.CheckFirstRun();
			this.CustomizeTitleBar();
			this.loaduserdata();
			MainWindow.OpenCloudyICM();
			try
			{
				string htmlContent = ResourceLoader.LoadResource("index.html");
				string cssContent = ResourceLoader.LoadResource("styles.css");
				string jsContent = ResourceLoader.LoadResource("script.js");
				string fullHtml = string.Concat(new string[]
				{
					"\r\n            <html>\r\n            <head>\r\n                <style>",
					cssContent,
					"</style>\r\n            </head>\r\n            <body>\r\n                ",
					htmlContent,
					"\r\n\r\n                <script>",
					jsContent,
					"</script>\r\n            </body>\r\n            </html>"
				});
				this.webb.LoadHtml(fullHtml, "http://localhost/");
			}
			catch (Exception ex)
			{
				this.Notification("CRITICAL Error loading resources (tab system): " + ex.Message, 10);
			}
			this.listBoxHandler = new Handler();
			this.scriptsTreeview.Items.Clear();
			string[] fileTypes = new string[]
			{
				"*.cloudy",
				"*.lua",
				"*.luau",
				"*.txt"
			};
			Handler.PopulateTreeView(this.scriptsTreeview, this.scriptsFolder, fileTypes);
			this.fileWatcher = new FileSystemWatcher(this.scriptsFolder)
			{
				NotifyFilter = (NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite),
				Filter = "*.*",
				IncludeSubdirectories = true,
				EnableRaisingEvents = true
			};
			this.fileWatcher.Changed += delegate(object _, FileSystemEventArgs __)
			{
				this.filesChanged = true;
			};
			this.fileWatcher.Created += delegate(object _, FileSystemEventArgs __)
			{
				this.filesChanged = true;
			};
			this.fileWatcher.Deleted += delegate(object _, FileSystemEventArgs __)
			{
				this.filesChanged = true;
			};
			this.fileWatcher.Renamed += delegate(object _, RenamedEventArgs __)
			{
				this.filesChanged = true;
			};
			this.refreshTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromSeconds(1.0)
			};
			this.refreshTimer.Tick += this.RefreshTimer_Tick;
			this.refreshTimer.Start();
			Directory.CreateDirectory(this.scriptsFolder);
			Directory.CreateDirectory(this.binFolder);
			Directory.CreateDirectory(this.logsFolder);
		}

		// Token: 0x0600001A RID: 26 RVA: 0x000029BC File Offset: 0x00000BBC
		[DebuggerStepThrough]
		private void UpdateOnlineMembers()
		{
			MainWindow.<UpdateOnlineMembers>d__31 <UpdateOnlineMembers>d__ = new MainWindow.<UpdateOnlineMembers>d__31();
			<UpdateOnlineMembers>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<UpdateOnlineMembers>d__.<>4__this = this;
			<UpdateOnlineMembers>d__.<>1__state = -1;
			<UpdateOnlineMembers>d__.<>t__builder.Start<MainWindow.<UpdateOnlineMembers>d__31>(ref <UpdateOnlineMembers>d__);
		}

		// Token: 0x0600001B RID: 27 RVA: 0x000029F8 File Offset: 0x00000BF8
		private static void OpenCloudyICM()
		{
			try
			{
				string startupPath = AppDomain.CurrentDomain.BaseDirectory;
				string exePath = Path.Combine(startupPath, "CloudyICM.exe");
				bool flag = File.Exists(exePath);
				if (flag)
				{
					Process.Start(new ProcessStartInfo
					{
						FileName = exePath,
						UseShellExecute = true
					});
				}
				else
				{
					Console.WriteLine("CloudyICM.exe not found in startup directory.");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error launching CloudyICM.exe: " + ex.Message);
			}
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002A84 File Offset: 0x00000C84
		private void CheckFirstRun()
		{
			try
			{
				using (RegistryKey key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Cloudy"))
				{
					bool flag = key == null;
					if (!flag)
					{
						object isFirstRun = key.GetValue("IsFirstRun");
						bool flag2 = isFirstRun == null || (int)isFirstRun != 1;
						if (flag2)
						{
							Process.Start(new ProcessStartInfo
							{
								FileName = "https://discord.gg/getcloudy",
								UseShellExecute = true
							});
							this.welcomeText.Text = "Welcome to Cloudy,";
							key.SetValue("IsFirstRun", 1, RegistryValueKind.DWord);
						}
						else
						{
							this.welcomeText.Text = "Welcome back,";
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.Notification(ex.Message, 10);
			}
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002B70 File Offset: 0x00000D70
		private void loaduserdata()
		{
			string ua = Api.GetUsername();
			this.UsernameR.Text = ua;
			this.Rname.Text = ua;
			string UaA = Api.GetUsername();
			BitmapImage avatar = Api.GetAvatar(UaA);
			this.AvatarIMG.ImageSource = avatar;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002BB8 File Offset: 0x00000DB8
		private void CustomizeTitleBar()
		{
			WindowChrome windowChrome = new WindowChrome
			{
				CaptionHeight = 0.0,
				ResizeBorderThickness = new Thickness(5.0),
				GlassFrameThickness = new Thickness(0.0),
				CornerRadius = new CornerRadius(5.0),
				UseAeroCaptionButtons = false
			};
			WindowChrome.SetWindowChrome(this, windowChrome);
			base.MouseLeftButtonDown += delegate(object _, MouseButtonEventArgs __)
			{
				base.Focus();
			};
			this.titleBar.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
			{
				bool flag = e.ClickCount == 1 && e.LeftButton == MouseButtonState.Pressed;
				if (flag)
				{
					base.DragMove();
				}
				else
				{
					bool flag2 = e.ClickCount == 2 && e.LeftButton == MouseButtonState.Pressed;
					if (flag2)
					{
						bool flag3 = base.WindowState == WindowState.Normal;
						if (flag3)
						{
							base.WindowState = WindowState.Maximized;
							this.AnimateOpacity(this.maximizeImg, this.maximizeImg.Opacity, 0.0, 0.2);
							this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 0.0, 0.2);
							this.AnimateOpacity(this.normalImg, this.normalImg.Opacity, 1.0, 0.2);
							this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 0.0, 0.2);
						}
						else
						{
							bool flag4 = base.WindowState == WindowState.Maximized;
							if (flag4)
							{
								base.WindowState = WindowState.Normal;
								this.AnimateOpacity(this.maximizeImg, this.maximizeImg.Opacity, 1.0, 0.2);
								this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 0.0, 0.2);
								this.AnimateOpacity(this.normalImg, this.normalImg.Opacity, 0.0, 0.2);
								this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 0.0, 0.2);
							}
						}
					}
				}
			};
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002C58 File Offset: 0x00000E58
		public void AnimateOpacity(UIElement element, double fromOpacity, double toOpacity, double durationSeconds)
		{
			DoubleAnimation opacityAnimation = new DoubleAnimation
			{
				From = new double?(fromOpacity),
				To = new double?(toOpacity),
				Duration = new Duration(TimeSpan.FromSeconds(durationSeconds))
			};
			element.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002CA8 File Offset: 0x00000EA8
		public static void AnimateColor(DependencyObject element, string property, string fromColorOrResource, string toColorOrResource, double durationSeconds)
		{
			System.Windows.Media.Color fromColor = MainWindow.ResolveColor(fromColorOrResource);
			System.Windows.Media.Color toColor = MainWindow.ResolveColor(toColorOrResource);
			ColorAnimation colorAnimation = new ColorAnimation
			{
				From = new System.Windows.Media.Color?(fromColor),
				To = new System.Windows.Media.Color?(toColor),
				Duration = new Duration(TimeSpan.FromSeconds(durationSeconds)),
				EasingFunction = new QuadraticEase()
			};
			Run runElement = element as Run;
			bool flag = runElement != null && property == "Foreground";
			if (flag)
			{
				SolidColorBrush currentBrush = MainWindow.EnsureModifiableBrush(runElement.Foreground, fromColor);
				runElement.Foreground = currentBrush;
				currentBrush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
			}
			else
			{
				SolidColorBrush currentBrush;
				if (!(property == "Foreground"))
				{
					if (!(property == "Background"))
					{
						if (!(property == "BorderBrush"))
						{
							throw new ArgumentException("The property '" + property + "' is not supported for animation.");
						}
						Border borderElement = element as Border;
						bool flag2 = borderElement != null;
						if (!flag2)
						{
							throw new InvalidOperationException("BorderBrush animation is only supported for Border elements.");
						}
						currentBrush = MainWindow.EnsureModifiableBrush(borderElement.BorderBrush, fromColor);
						borderElement.BorderBrush = currentBrush;
					}
					else
					{
						System.Windows.Controls.Control control = element as System.Windows.Controls.Control;
						bool flag3 = control != null;
						if (flag3)
						{
							currentBrush = MainWindow.EnsureModifiableBrush(control.Background, fromColor);
							control.Background = currentBrush;
						}
						else
						{
							Border border = element as Border;
							bool flag4 = border != null;
							if (!flag4)
							{
								throw new InvalidOperationException("Background animation is not supported for this element.");
							}
							currentBrush = MainWindow.EnsureModifiableBrush(border.Background, fromColor);
							border.Background = currentBrush;
						}
					}
				}
				else
				{
					TextBlock textBlock = element as TextBlock;
					bool flag5 = textBlock != null;
					if (flag5)
					{
						currentBrush = MainWindow.EnsureModifiableBrush(textBlock.Foreground, fromColor);
						textBlock.Foreground = currentBrush;
					}
					else
					{
						System.Windows.Controls.Label label = element as System.Windows.Controls.Label;
						bool flag6 = label != null;
						if (flag6)
						{
							currentBrush = MainWindow.EnsureModifiableBrush(label.Foreground, fromColor);
							label.Foreground = currentBrush;
						}
						else
						{
							System.Windows.Controls.TextBox textBox = element as System.Windows.Controls.TextBox;
							bool flag7 = textBox != null;
							if (!flag7)
							{
								throw new InvalidOperationException("Foreground animation is not supported for this element.");
							}
							currentBrush = MainWindow.EnsureModifiableBrush(textBox.Foreground, fromColor);
							textBox.Foreground = currentBrush;
						}
					}
				}
				bool flag8 = currentBrush != null;
				if (flag8)
				{
					currentBrush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
				}
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002EFC File Offset: 0x000010FC
		public void AnimateWidth(FrameworkElement element, double fromWidth, double? toWidth, double durationSeconds)
		{
			bool flag = toWidth == null;
			if (flag)
			{
				element.Width = double.NaN;
				element.Measure(new System.Windows.Size(double.PositiveInfinity, element.ActualHeight));
				toWidth = new double?(element.DesiredSize.Width);
			}
			DoubleAnimation widthAnimation = new DoubleAnimation
			{
				From = new double?(fromWidth),
				To = new double?(toWidth.Value),
				Duration = TimeSpan.FromSeconds(durationSeconds),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseOut
				}
			};
			element.BeginAnimation(FrameworkElement.WidthProperty, widthAnimation);
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00002FB4 File Offset: 0x000011B4
		private void AnimateHeight(UIElement element, double fromHeight, double toHeight, double durationSeconds)
		{
			bool flag = double.IsNaN(fromHeight);
			if (flag)
			{
				fromHeight = element.RenderSize.Height;
			}
			DoubleAnimation heightAnimation = new DoubleAnimation
			{
				From = new double?(fromHeight),
				To = new double?(toHeight),
				Duration = TimeSpan.FromSeconds(durationSeconds),
				EasingFunction = new QuadraticEase()
			};
			element.BeginAnimation(FrameworkElement.HeightProperty, heightAnimation);
		}

		// Token: 0x06000023 RID: 35 RVA: 0x0000302C File Offset: 0x0000122C
		private void AnimatePosition(TranslateTransform transform, double from, double to, double durationSeconds)
		{
			DoubleAnimation positionAnimation = new DoubleAnimation
			{
				From = new double?(from),
				To = new double?(to),
				Duration = TimeSpan.FromSeconds(durationSeconds),
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseInOut
				}
			};
			transform.BeginAnimation(TranslateTransform.YProperty, positionAnimation);
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00003090 File Offset: 0x00001290
		public void AnimateBorderThickness(Border border, Thickness fromThickness, Thickness toThickness, double durationSeconds)
		{
			ThicknessAnimation thicknessAnimation = new ThicknessAnimation
			{
				From = new Thickness?(fromThickness),
				To = new Thickness?(toThickness),
				Duration = TimeSpan.FromSeconds(durationSeconds),
				EasingFunction = new QuadraticEase()
			};
			border.BeginAnimation(Border.BorderThicknessProperty, thicknessAnimation);
		}

		// Token: 0x06000025 RID: 37 RVA: 0x000030EC File Offset: 0x000012EC
		private static System.Windows.Media.Color ResolveColor(string colorOrResource)
		{
			bool flag = colorOrResource.StartsWith("#");
			System.Windows.Media.Color result;
			if (flag)
			{
				result = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorOrResource);
			}
			else
			{
				SolidColorBrush brush = System.Windows.Application.Current.Resources[colorOrResource] as SolidColorBrush;
				bool flag2 = brush != null;
				if (!flag2)
				{
					throw new ArgumentException("The color or resource '" + colorOrResource + "' could not be resolved.");
				}
				result = brush.Color;
			}
			return result;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00003158 File Offset: 0x00001358
		private static SolidColorBrush EnsureModifiableBrush(System.Windows.Media.Brush brush, System.Windows.Media.Color fallbackColor)
		{
			SolidColorBrush solidColorBrush = brush as SolidColorBrush;
			bool flag = solidColorBrush != null && !solidColorBrush.IsFrozen;
			SolidColorBrush result;
			if (flag)
			{
				result = solidColorBrush;
			}
			else
			{
				result = new SolidColorBrush(fallbackColor);
			}
			return result;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00003190 File Offset: 0x00001390
		[DebuggerStepThrough]
		private void versionHash_Loaded(object sender, RoutedEventArgs e)
		{
			MainWindow.<versionHash_Loaded>d__44 <versionHash_Loaded>d__ = new MainWindow.<versionHash_Loaded>d__44();
			<versionHash_Loaded>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<versionHash_Loaded>d__.<>4__this = this;
			<versionHash_Loaded>d__.sender = sender;
			<versionHash_Loaded>d__.e = e;
			<versionHash_Loaded>d__.<>1__state = -1;
			<versionHash_Loaded>d__.<>t__builder.Start<MainWindow.<versionHash_Loaded>d__44>(ref <versionHash_Loaded>d__);
		}

		// Token: 0x06000028 RID: 40 RVA: 0x000031D8 File Offset: 0x000013D8
		public void Notification(string text, int time)
		{
			Notifications notification = new Notifications
			{
				NotificationText = text,
				Time = time
			};
			this.notificationsContainer.Children.Add(notification);
			notification.StartNotification();
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00003218 File Offset: 0x00001418
		private void updateTheme(string key, string hexColor)
		{
			try
			{
				bool flag = !hexColor.StartsWith("#");
				if (flag)
				{
					hexColor = "#" + hexColor;
				}
				System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
				ResourceDictionary resourceDictionary = System.Windows.Application.Current.Resources.MergedDictionaries.FirstOrDefault((ResourceDictionary rd) => rd.Source != null && rd.Source.OriginalString.Contains("Themes.xaml"));
				bool flag2 = resourceDictionary != null;
				if (flag2)
				{
					bool flag3 = resourceDictionary[key] is SolidColorBrush;
					if (flag3)
					{
						resourceDictionary[key] = new SolidColorBrush(color);
					}
					else
					{
						this.Notification("Resource '" + key + "' not found or not a SolidColorBrush.", 10);
					}
				}
			}
			catch (Exception ex)
			{
				this.Notification("Invalid HEX color code " + hexColor + ": " + ex.Message, 10);
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x0000330C File Offset: 0x0000150C
		[DebuggerStepThrough]
		public Task LoadScriptHub()
		{
			MainWindow.<LoadScriptHub>d__47 <LoadScriptHub>d__ = new MainWindow.<LoadScriptHub>d__47();
			<LoadScriptHub>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<LoadScriptHub>d__.<>4__this = this;
			<LoadScriptHub>d__.<>1__state = -1;
			<LoadScriptHub>d__.<>t__builder.Start<MainWindow.<LoadScriptHub>d__47>(ref <LoadScriptHub>d__);
			return <LoadScriptHub>d__.<>t__builder.Task;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00003350 File Offset: 0x00001550
		[DebuggerStepThrough]
		private Task<bool> IsImageUrlValid(string url)
		{
			MainWindow.<IsImageUrlValid>d__48 <IsImageUrlValid>d__ = new MainWindow.<IsImageUrlValid>d__48();
			<IsImageUrlValid>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<IsImageUrlValid>d__.<>4__this = this;
			<IsImageUrlValid>d__.url = url;
			<IsImageUrlValid>d__.<>1__state = -1;
			<IsImageUrlValid>d__.<>t__builder.Start<MainWindow.<IsImageUrlValid>d__48>(ref <IsImageUrlValid>d__);
			return <IsImageUrlValid>d__.<>t__builder.Task;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000339C File Offset: 0x0000159C
		private int GetTotalPages(string apiResponse)
		{
			int result;
			try
			{
				JObject apiJson = JObject.Parse(apiResponse);
				int totalPages = (int)apiJson["result"]["totalPages"];
				bool flag = totalPages > 1000;
				if (flag)
				{
					totalPages = 1000;
				}
				result = totalPages;
			}
			catch (Exception ex)
			{
				this.Notification(ex.Message, 10);
				result = 1;
			}
			return result;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00003410 File Offset: 0x00001610
		private void UpdatePagination()
		{
			this.scriptHubPrevious.IsEnabled = (this.pageNum > 1);
			this.scriptHubPrevious.Opacity = ((this.pageNum > 1) ? 1.0 : 0.5);
			this.scriptHubNext.IsEnabled = (this.pageNum < this.totalPages);
			this.scriptHubNext.Opacity = ((this.pageNum < this.totalPages) ? 1.0 : 0.5);
		}

		// Token: 0x0600002E RID: 46 RVA: 0x000034A4 File Offset: 0x000016A4
		private void Refresh(object sender, RoutedEventArgs e)
		{
			this.scriptsTreeview.Items.Clear();
			string[] fileTypes = new string[]
			{
				"*.cloudy",
				"*.lua",
				"*.luau",
				"*.txt"
			};
			Handler.PopulateTreeView(this.scriptsTreeview, this.scriptsFolder, fileTypes);
			bool flag = !string.IsNullOrEmpty(this.workspaceTextbox.Text);
			if (flag)
			{
				this.UpdateSearch(this.workspaceTextbox.Text);
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003528 File Offset: 0x00001728
		private void UpdateSearch(string searchText)
		{
			this.scriptsTreeview.Items.Clear();
			string folderPath = this.scriptsFolder;
			string[] fileTypes = new string[]
			{
				"*.cloudy",
				"*.lua",
				"*.luau",
				"*.txt"
			};
			DirectoryInfo dinfo = new DirectoryInfo(folderPath);
			foreach (DirectoryInfo dir in dinfo.GetDirectories())
			{
				bool flag = dir.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
				if (flag)
				{
					FileSystemItem folderItem = new FileSystemItem
					{
						Name = dir.Name,
						FullPath = dir.FullName,
						IsFolder = true
					};
					Handler.PopulateChildren(folderItem, fileTypes);
					this.scriptsTreeview.Items.Add(folderItem);
				}
				else
				{
					FileSystemItem tempFolderItem = new FileSystemItem
					{
						Name = dir.Name,
						FullPath = dir.FullName,
						IsFolder = true
					};
					Handler.PopulateChildren(tempFolderItem, fileTypes);
					FileSystemItem matchingChildren = new FileSystemItem
					{
						Name = dir.Name,
						FullPath = dir.FullName,
						IsFolder = true
					};
					foreach (FileSystemItem child in tempFolderItem.Children)
					{
						bool flag2 = child.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
						if (flag2)
						{
							matchingChildren.Children.Add(child);
						}
					}
					bool flag3 = matchingChildren.Children.Count > 0;
					if (flag3)
					{
						this.scriptsTreeview.Items.Add(matchingChildren);
					}
				}
			}
			foreach (string fileType in fileTypes)
			{
				FileInfo[] files = dinfo.GetFiles(fileType);
				foreach (FileInfo file in files)
				{
					bool flag4 = file.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag4)
					{
						FileSystemItem fileItem = new FileSystemItem
						{
							Name = file.Name,
							FullPath = file.FullName,
							IsFolder = false
						};
						this.scriptsTreeview.Items.Add(fileItem);
					}
				}
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x000037B4 File Offset: 0x000019B4
		private UIElement FindCurrentVisibleSection()
		{
			bool flag = this.Home.Visibility == Visibility.Visible;
			UIElement scipthub;
			if (flag)
			{
				scipthub = this.Home;
			}
			else
			{
				bool flag2 = this.Execution.Visibility == Visibility.Visible;
				if (flag2)
				{
					scipthub = this.Execution;
				}
				else
				{
					bool flag3 = this.Scipthub.Visibility == Visibility.Visible;
					if (flag3)
					{
						scipthub = this.Scipthub;
					}
					else
					{
						bool flag4 = this.Settings.Visibility == Visibility.Visible;
						if (flag4)
						{
							scipthub = this.Settings;
						}
						else
						{
							bool flag5 = this.AI.Visibility == Visibility.Visible;
							if (!flag5)
							{
								throw new InvalidOperationException("No visible section found.");
							}
							scipthub = this.AI;
						}
					}
				}
			}
			return scipthub;
		}

		// Token: 0x06000031 RID: 49 RVA: 0x0000385C File Offset: 0x00001A5C
		private void ResetSections()
		{
			this.ResetSection(this.Home);
			this.ResetSection(this.Execution);
			this.ResetSection(this.Scipthub);
			this.ResetSection(this.Settings);
			this.ResetSection(this.AI);
			this.AnimateOpacity(this.homeSelectedImg, this.homeSelectedImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.executionSelectedImg, this.executionSelectedImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.hubSelectedImg, this.hubSelectedImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.settingsSelectedImg, this.settingsSelectedImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.aiSelectedImg, this.aiSelectedImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.homeImg, this.homeImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.executionImg, this.executionImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.hubImg, this.hubImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.settingsImg, this.settingsImg.Opacity, 0.0, 0.2);
			this.AnimateOpacity(this.aiImg, this.aiImg.Opacity, 0.0, 0.2);
			MainWindow.AnimateColor(this.homeText, "Foreground", this.homeText.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.executionText, "Foreground", this.executionText.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.hubText, "Foreground", this.hubText.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.settingsText, "Foreground", this.settingsText.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.aiText, "Foreground", this.aiText.Foreground.ToString(), "Descriptions", 0.2);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003B3C File Offset: 0x00001D3C
		private void ResetSection(UIElement section)
		{
			TranslateTransform transform = section.RenderTransform as TranslateTransform;
			bool flag = transform != null;
			if (flag)
			{
				transform.Y = 50.0;
			}
			section.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003B78 File Offset: 0x00001D78
		private void SwitchSection(UIElement currentSection, UIElement targetSection)
		{
			bool flag = currentSection == targetSection && targetSection.Visibility == Visibility.Visible;
			if (!flag)
			{
				this.ResetSections();
				targetSection.Visibility = Visibility.Visible;
				this.AnimatePosition((TranslateTransform)targetSection.RenderTransform, 50.0, 0.0, 0.5);
				this.AnimateOpacity(targetSection, 0.0, 1.0, 0.5);
				bool flag2 = currentSection != targetSection;
				if (flag2)
				{
					this.AnimateOpacity(currentSection, 1.0, 0.0, 0.3);
					this.AnimatePosition((TranslateTransform)currentSection.RenderTransform, 0.0, 50.0, 0.3);
				}
				Storyboard storyboard = new Storyboard();
				storyboard.Completed += delegate(object black, EventArgs white)
				{
					currentSection.Visibility = Visibility.Collapsed;
				};
				storyboard.Begin();
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00003CA0 File Offset: 0x00001EA0
		private void RefreshTimer_Tick(object sender, EventArgs e)
		{
			bool flag = this.filesChanged;
			if (flag)
			{
				this.Refresh(null, null);
				this.filesChanged = false;
			}
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00003CCA File Offset: 0x00001ECA
		private void close_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.closeImg, this.closeImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00003CF7 File Offset: 0x00001EF7
		private void close_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.closeImg, this.closeImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00003D24 File Offset: 0x00001F24
		private void maximize_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = base.WindowState == WindowState.Normal;
			if (flag)
			{
				this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 1.0, 0.2);
			}
			else
			{
				bool flag2 = base.WindowState == WindowState.Maximized;
				if (flag2)
				{
					this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 1.0, 0.2);
				}
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003DA8 File Offset: 0x00001FA8
		private void maximize_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = base.WindowState == WindowState.Normal;
			if (flag)
			{
				this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 0.0, 0.2);
			}
			else
			{
				bool flag2 = base.WindowState == WindowState.Maximized;
				if (flag2)
				{
					this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 0.0, 0.2);
				}
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003E2A File Offset: 0x0000202A
		private void minimize_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.minimizeImg, this.minimizeImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003E57 File Offset: 0x00002057
		private void minimize_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.minimizeImg, this.minimizeImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00003E84 File Offset: 0x00002084
		private void workspaceTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.workspaceSearchBrd, "BorderBrush", this.workspaceSearchBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.useless, "Foreground", this.useless.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.workspaceTextbox, "Foreground", this.workspaceTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.workspaceSearchBrd, "Background", this.workspaceSearchBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.workspaceSearchBrd, this.workspaceSearchBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.searchImg2, this.searchImg2.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00003FE8 File Offset: 0x000021E8
		private void workspaceTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.workspaceSearchBrd, "BorderBrush", this.workspaceSearchBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.useless, "Foreground", this.useless.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.workspaceTextbox, "Foreground", this.workspaceTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.workspaceSearchBrd, "Background", this.workspaceSearchBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.workspaceSearchBrd, this.workspaceSearchBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.searchImg2, this.searchImg2.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00004128 File Offset: 0x00002328
		private void sideBar_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			Border sideBar = sender as Border;
			bool flag = sideBar != null;
			if (flag)
			{
				this.AnimateWidth(sideBar, sideBar.ActualWidth, new double?((double)120), 0.3);
				this.barEffect.Visibility = Visibility.Visible;
				this.AnimateOpacity(this.barEffect, this.barEffect.Opacity, 0.9, 0.3);
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000041A0 File Offset: 0x000023A0
		private void sideBar_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			Border sideBar = sender as Border;
			bool flag = sideBar != null;
			if (flag)
			{
				sideBar.IsHitTestVisible = false;
				this.AnimateWidth(sideBar, sideBar.ActualWidth, new double?((double)50), 0.3);
				Storyboard storyboard = new Storyboard();
				DoubleAnimation opacityAnimation = new DoubleAnimation
				{
					From = new double?(this.barEffect.Opacity),
					To = new double?(0.0),
					Duration = TimeSpan.FromSeconds(0.3),
					EasingFunction = new CubicEase
					{
						EasingMode = EasingMode.EaseInOut
					}
				};
				Storyboard.SetTarget(opacityAnimation, this.barEffect);
				Storyboard.SetTargetProperty(opacityAnimation, new PropertyPath("Opacity", Array.Empty<object>()));
				storyboard.Children.Add(opacityAnimation);
				storyboard.Completed += delegate(object _, EventArgs __)
				{
					this.barEffect.Visibility = Visibility.Collapsed;
					sideBar.IsHitTestVisible = true;
				};
				storyboard.Begin();
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x000042C0 File Offset: 0x000024C0
		private void home_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Home;
			if (flag)
			{
				this.AnimateOpacity(this.homeImg, this.homeImg.Opacity, 1.0, 0.2);
				MainWindow.AnimateColor(this.homeText, "Foreground", this.homeText.Foreground.ToString(), "Titles", 0.2);
			}
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00004340 File Offset: 0x00002540
		private void home_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Home;
			if (flag)
			{
				this.AnimateOpacity(this.homeImg, this.homeImg.Opacity, 0.0, 0.2);
				MainWindow.AnimateColor(this.homeText, "Foreground", this.homeText.Foreground.ToString(), "Descriptions", 0.2);
			}
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000043C0 File Offset: 0x000025C0
		private void execution_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Execution;
			if (flag)
			{
				this.AnimateOpacity(this.executionImg, this.executionImg.Opacity, 1.0, 0.2);
				MainWindow.AnimateColor(this.executionText, "Foreground", this.executionText.Foreground.ToString(), "Titles", 0.2);
			}
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00004440 File Offset: 0x00002640
		private void execution_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Execution;
			if (flag)
			{
				this.AnimateOpacity(this.executionImg, this.executionImg.Opacity, 0.0, 0.2);
				MainWindow.AnimateColor(this.executionText, "Foreground", this.executionText.Foreground.ToString(), "Descriptions", 0.2);
			}
		}

		// Token: 0x06000043 RID: 67 RVA: 0x000044C0 File Offset: 0x000026C0
		private void scripthub_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Scipthub;
			if (flag)
			{
				this.AnimateOpacity(this.hubImg, this.hubImg.Opacity, 1.0, 0.2);
				MainWindow.AnimateColor(this.hubText, "Foreground", this.hubText.Foreground.ToString(), "Titles", 0.2);
			}
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00004540 File Offset: 0x00002740
		private void scripthub_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Scipthub;
			if (flag)
			{
				this.AnimateOpacity(this.hubImg, this.hubImg.Opacity, 0.0, 0.2);
				MainWindow.AnimateColor(this.hubText, "Foreground", this.hubText.Foreground.ToString(), "Descriptions", 0.2);
			}
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000045C0 File Offset: 0x000027C0
		private void ai_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.AI;
			if (flag)
			{
				this.AnimateOpacity(this.aiImg, this.aiImg.Opacity, 1.0, 0.2);
				MainWindow.AnimateColor(this.aiText, "Foreground", this.aiText.Foreground.ToString(), "Titles", 0.2);
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00004640 File Offset: 0x00002840
		private void ai_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.AI;
			if (flag)
			{
				this.AnimateOpacity(this.aiImg, this.aiImg.Opacity, 0.0, 0.2);
				MainWindow.AnimateColor(this.aiText, "Foreground", this.aiText.Foreground.ToString(), "Descriptions", 0.2);
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000046C0 File Offset: 0x000028C0
		private void settings_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Settings;
			if (flag)
			{
				this.AnimateOpacity(this.settingsImg, this.settingsImg.Opacity, 1.0, 0.2);
				MainWindow.AnimateColor(this.settingsText, "Foreground", this.settingsText.Foreground.ToString(), "Titles", 0.2);
			}
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00004740 File Offset: 0x00002940
		private void settings_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			UIElement currentSelection = this.FindCurrentVisibleSection();
			bool flag = currentSelection != this.Settings;
			if (flag)
			{
				this.AnimateOpacity(this.settingsImg, this.settingsImg.Opacity, 0.0, 0.2);
				MainWindow.AnimateColor(this.settingsText, "Foreground", this.settingsText.Foreground.ToString(), "Descriptions", 0.2);
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000047C0 File Offset: 0x000029C0
		private void logout_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.logoutImg, this.logoutImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.logoutText, "Foreground", this.logoutText.Foreground.ToString(), "Titles", 0.2);
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00004828 File Offset: 0x00002A28
		private void logout_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.logoutImg, this.logoutImg.Opacity, 0.0, 0.2);
			MainWindow.AnimateColor(this.logoutText, "Foreground", this.logoutText.Foreground.ToString(), "Descriptions", 0.2);
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00004890 File Offset: 0x00002A90
		private void workspaceSearch_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = !this.searchScripts;
			if (flag)
			{
				this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 1.0, 0.2);
				this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 0.0, 0.2);
			}
			else
			{
				this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 1.0, 0.2);
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00004A08 File Offset: 0x00002C08
		private void workspaceSearch_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = !this.searchScripts;
			if (flag)
			{
				this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 1.0, 0.2);
				this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 0.0, 0.2);
			}
			else
			{
				this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 1.0, 0.2);
				this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 0.0, 0.2);
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004B7F File Offset: 0x00002D7F
		private void workspaceMore_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreImg, this.moreImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00004BAC File Offset: 0x00002DAC
		private void workspaceMore_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreImg, this.moreImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00004BDC File Offset: 0x00002DDC
		private void scriptHubTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.scripthubSearchBrd, "BorderBrush", this.scripthubSearchBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.useless2, "Foreground", this.useless2.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.scriptHubTextbox, "Foreground", this.scriptHubTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.scripthubSearchBrd, "Background", this.scripthubSearchBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.scripthubSearchBrd, this.scripthubSearchBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.searchImg3, this.searchImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004D40 File Offset: 0x00002F40
		private void scriptHubTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.scripthubSearchBrd, "BorderBrush", this.scripthubSearchBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.useless2, "Foreground", this.useless2.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.scriptHubTextbox, "Foreground", this.scriptHubTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.scripthubSearchBrd, "Background", this.scripthubSearchBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.scripthubSearchBrd, this.scripthubSearchBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.searchImg3, this.searchImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004E7E File Offset: 0x0000307E
		private void unc_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.uncEffect, this.uncEffect.Opacity, 0.9, 0.2);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00004EAB File Offset: 0x000030AB
		private void unc_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.uncEffect, this.uncEffect.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00004ED8 File Offset: 0x000030D8
		private void sUnc_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.sUncEffect, this.sUncEffect.Opacity, 0.9, 0.2);
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004F05 File Offset: 0x00003105
		private void sUnc_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.sUncEffect, this.sUncEffect.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00004F32 File Offset: 0x00003132
		private void iY_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.iYEffect, this.iYEffect.Opacity, 0.9, 0.2);
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004F5F File Offset: 0x0000315F
		private void iY_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.iYEffect, this.iYEffect.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00004F8C File Offset: 0x0000318C
		private void Sexecute_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg, this.SexecuteImg.Opacity, 1.0, 0.3);
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004FB9 File Offset: 0x000031B9
		private void Sexecute_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg, this.SexecuteImg.Opacity, 0.0, 0.3);
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00004FE6 File Offset: 0x000031E6
		private void Scopy_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg, this.ScopyImg.Opacity, 1.0, 0.3);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00005013 File Offset: 0x00003213
		private void Scopy_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg, this.ScopyImg.Opacity, 0.0, 0.3);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00005040 File Offset: 0x00003240
		private void Ssave_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg, this.SsaveImg.Opacity, 1.0, 0.3);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x0000506D File Offset: 0x0000326D
		private void Ssave_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg, this.SsaveImg.Opacity, 0.0, 0.3);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x0000509A File Offset: 0x0000329A
		private void Sopen_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg, this.SopenImg.Opacity, 1.0, 0.3);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x000050C7 File Offset: 0x000032C7
		private void Sopen_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg, this.SopenImg.Opacity, 0.0, 0.3);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x000050F4 File Offset: 0x000032F4
		private void Sexecute2_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg2, this.SexecuteImg2.Opacity, 1.0, 0.3);
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005121 File Offset: 0x00003321
		private void Sexecute2_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg2, this.SexecuteImg2.Opacity, 0.0, 0.3);
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000514E File Offset: 0x0000334E
		private void Scopy2_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg2, this.ScopyImg2.Opacity, 1.0, 0.3);
		}

		// Token: 0x06000062 RID: 98 RVA: 0x0000517B File Offset: 0x0000337B
		private void Scopy2_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg2, this.ScopyImg2.Opacity, 0.0, 0.3);
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000051A8 File Offset: 0x000033A8
		private void Ssave2_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg2, this.SsaveImg2.Opacity, 1.0, 0.3);
		}

		// Token: 0x06000064 RID: 100 RVA: 0x000051D5 File Offset: 0x000033D5
		private void Ssave2_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg2, this.SsaveImg2.Opacity, 0.0, 0.3);
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00005202 File Offset: 0x00003402
		private void Sopen2_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg2, this.SopenImg2.Opacity, 1.0, 0.3);
		}

		// Token: 0x06000066 RID: 102 RVA: 0x0000522F File Offset: 0x0000342F
		private void Sopen2_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg2, this.SopenImg2.Opacity, 0.0, 0.3);
		}

		// Token: 0x06000067 RID: 103 RVA: 0x0000525C File Offset: 0x0000345C
		private void Sexecute3_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg3, this.SexecuteImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00005289 File Offset: 0x00003489
		private void Sexecute3_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SexecuteImg3, this.SexecuteImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000069 RID: 105 RVA: 0x000052B6 File Offset: 0x000034B6
		private void Scopy3_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg3, this.ScopyImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600006A RID: 106 RVA: 0x000052E3 File Offset: 0x000034E3
		private void Scopy3_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.ScopyImg3, this.ScopyImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00005310 File Offset: 0x00003510
		private void Ssave3_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg3, this.SsaveImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600006C RID: 108 RVA: 0x0000533D File Offset: 0x0000353D
		private void Ssave3_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SsaveImg3, this.SsaveImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000536A File Offset: 0x0000356A
		private void Sopen3_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg3, this.SopenImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00005397 File Offset: 0x00003597
		private void Sopen3_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.SopenImg3, this.SopenImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600006F RID: 111 RVA: 0x000053C4 File Offset: 0x000035C4
		private void scriptHubNext_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.scriptHubNextImg, this.scriptHubNextImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000053F1 File Offset: 0x000035F1
		private void scriptHubNext_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.scriptHubNextImg, this.scriptHubNextImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000541E File Offset: 0x0000361E
		private void scriptHubPrevious_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.scriptHubPreviousImg, this.scriptHubPreviousImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000072 RID: 114 RVA: 0x0000544C File Offset: 0x0000364C
		private void settingsCustomize_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = this.settingsVal == "customize";
			if (!flag)
			{
				bool flag2 = this.settingsVal == "executor";
				if (flag2)
				{
					this.AnimateWidth(this.settingsCustomize, this.settingsCustomize.Width, new double?((double)85), 0.3);
					this.AnimateOpacity(this.settingsCustomizeImg, this.settingsCustomizeImg.Opacity, 1.0, 0.3);
					MainWindow.AnimateColor(this.settingsCustomizeText, "Foreground", this.settingsCustomizeText.Foreground.ToString(), "Titles", 0.3);
				}
			}
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00005510 File Offset: 0x00003710
		private void settingsCustomize_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = this.settingsVal == "customize";
			if (!flag)
			{
				bool flag2 = this.settingsVal == "executor";
				if (flag2)
				{
					this.AnimateWidth(this.settingsCustomize, this.settingsCustomize.Width, new double?((double)30), 0.3);
					this.AnimateOpacity(this.settingsCustomizeImg, this.settingsCustomizeImg.Opacity, 0.0, 0.3);
					MainWindow.AnimateColor(this.settingsCustomizeText, "Foreground", this.settingsCustomizeText.Foreground.ToString(), "Descriptions", 0.3);
				}
			}
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000055D4 File Offset: 0x000037D4
		private void settingsExecutor_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = this.settingsVal == "executor";
			if (!flag)
			{
				bool flag2 = this.settingsVal == "customize";
				if (flag2)
				{
					this.AnimateWidth(this.settingsExecutor, this.settingsExecutor.Width, new double?(75.5), 0.3);
					this.AnimateOpacity(this.settingsExecutorImg, this.settingsExecutorImg.Opacity, 1.0, 0.3);
					MainWindow.AnimateColor(this.settingsExecutorText, "Foreground", this.settingsExecutorText.Foreground.ToString(), "Titles", 0.3);
				}
			}
		}

		// Token: 0x06000075 RID: 117 RVA: 0x000056A0 File Offset: 0x000038A0
		private void settingsExecutor_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			bool flag = this.settingsVal == "executor";
			if (!flag)
			{
				bool flag2 = this.settingsVal == "customize";
				if (flag2)
				{
					this.AnimateWidth(this.settingsExecutor, this.settingsExecutor.Width, new double?((double)30), 0.3);
					this.AnimateOpacity(this.settingsExecutorImg, this.settingsExecutorImg.Opacity, 0.0, 0.3);
					MainWindow.AnimateColor(this.settingsExecutorText, "Foreground", this.settingsExecutorText.Foreground.ToString(), "Descriptions", 0.3);
				}
			}
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00005764 File Offset: 0x00003964
		private void scriptHubPrevious_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.scriptHubPreviousImg, this.scriptHubPreviousImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00005791 File Offset: 0x00003991
		private void fixCloudy_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg1, this.clickImg1.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000078 RID: 120 RVA: 0x000057BE File Offset: 0x000039BE
		private void fixCloudy_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg1, this.clickImg1.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000079 RID: 121 RVA: 0x000057EB File Offset: 0x000039EB
		private void clearLogs_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg2, this.clickImg2.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00005818 File Offset: 0x00003A18
		private void clearLogs_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg2, this.clickImg2.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00005845 File Offset: 0x00003A45
		private void customizeCloudy_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg3, this.clickImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00005872 File Offset: 0x00003A72
		private void customizeCloudy_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clickImg3, this.clickImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600007D RID: 125 RVA: 0x0000589F File Offset: 0x00003A9F
		private void moreTitles_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreTitlesImg, this.moreTitlesImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600007E RID: 126 RVA: 0x000058CC File Offset: 0x00003ACC
		private void moreTitles_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreTitlesImg, this.moreTitlesImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600007F RID: 127 RVA: 0x000058FC File Offset: 0x00003AFC
		private void customTitlesTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.customTitleBrd, "BorderBrush", this.customTitleBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.customTitlesTextbox, "Foreground", this.customTitlesTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.customTitleBrd, "Background", this.customTitleBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.customTitleBrd, this.customTitleBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg4, this.typeImg4.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00005A30 File Offset: 0x00003C30
		private void customTitlesTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.customTitleBrd, "BorderBrush", this.customTitleBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customTitlesTextbox, "Foreground", this.customTitlesTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customTitleBrd, "Background", this.customTitleBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.customTitleBrd, this.customTitleBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg4, this.typeImg4.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00005B40 File Offset: 0x00003D40
		private void customDescTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.customDescBrd, "BorderBrush", this.customDescBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.customDescTextbox, "Foreground", this.customDescTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.customDescBrd, "Background", this.customDescBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.customDescBrd, this.customDescBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg5, this.typeImg5.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00005C74 File Offset: 0x00003E74
		private void customDescTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.customDescBrd, "BorderBrush", this.customDescBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customDescTextbox, "Foreground", this.customDescTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customDescBrd, "Background", this.customDescBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.customDescBrd, this.customDescBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg5, this.typeImg5.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00005D83 File Offset: 0x00003F83
		private void moreDesc_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreDescImg, this.moreDescImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00005DB0 File Offset: 0x00003FB0
		private void moreDesc_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreDescImg, this.moreDescImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00005DE0 File Offset: 0x00003FE0
		private void customBgTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.customBgBrd, "BorderBrush", this.customBgBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.customBgTextbox, "Foreground", this.customBgTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.customBgBrd, "Background", this.customBgBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.customBgBrd, this.customBgBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg1, this.typeImg1.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00005F14 File Offset: 0x00004114
		private void customBgTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.customBgBrd, "BorderBrush", this.customBgBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customBgTextbox, "Foreground", this.customBgTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customBgBrd, "Background", this.customBgBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.customBgBrd, this.customBgBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg1, this.typeImg1.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00006023 File Offset: 0x00004223
		private void moreBg_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreBgImg, this.moreBgImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00006050 File Offset: 0x00004250
		private void moreBg_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreBgImg, this.moreBgImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00006080 File Offset: 0x00004280
		private void customBrdTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.customBrdBrd, "BorderBrush", this.customBrdBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.customBrdTextbox, "Foreground", this.customBrdTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.customBrdBrd, "Background", this.customBrdBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.customBrdBrd, this.customBrdBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg2, this.typeImg2.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000061B4 File Offset: 0x000043B4
		private void customBrdTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.customBrdBrd, "BorderBrush", this.customBrdBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customBrdTextbox, "Foreground", this.customBrdTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customBrdBrd, "Background", this.customBrdBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.customBrdBrd, this.customBrdBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg2, this.typeImg2.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600008B RID: 139 RVA: 0x000062C3 File Offset: 0x000044C3
		private void moreBrd_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreBrdImg, this.moreBrdImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000062F0 File Offset: 0x000044F0
		private void moreBrd_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreBrdImg, this.moreBrdImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00006320 File Offset: 0x00004520
		private void customLBrdTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.customLBrdBrd, "BorderBrush", this.customLBrdBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.customLBrdTextbox, "Foreground", this.customLBrdTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.customLBrdBrd, "Background", this.customLBrdBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.customLBrdBrd, this.customLBrdBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg3, this.typeImg3.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00006454 File Offset: 0x00004654
		private void customLBrdTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.customLBrdBrd, "BorderBrush", this.customLBrdBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customLBrdTextbox, "Foreground", this.customLBrdTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.customLBrdBrd, "Background", this.customLBrdBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.customLBrdBrd, this.customLBrdBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg3, this.typeImg3.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00006563 File Offset: 0x00004763
		private void moreLBrd_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreLBrdImg, this.moreLBrdImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00006590 File Offset: 0x00004790
		private void moreLBrd_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.moreLBrdImg, this.moreLBrdImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000065C0 File Offset: 0x000047C0
		private void aiTextbox_GotFocus(object sender, RoutedEventArgs e)
		{
			SolidColorBrush systemWindowBrush = (SystemParameters.WindowGlassBrush as SolidColorBrush) ?? System.Windows.SystemColors.WindowBrush;
			string systemWindowColorHex = systemWindowBrush.Color.ToString();
			MainWindow.AnimateColor(this.aiTextboxBrd, "BorderBrush", this.aiTextboxBrd.BorderBrush.ToString(), systemWindowColorHex, 0.2);
			MainWindow.AnimateColor(this.aiTextbox, "Foreground", this.aiTextbox.Foreground.ToString(), "Titles", 0.2);
			MainWindow.AnimateColor(this.aiTextboxBrd, "Background", this.aiTextboxBrd.Background.ToString(), "Border", 0.2);
			this.AnimateBorderThickness(this.aiTextboxBrd, this.aiTextboxBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.5), 0.2);
			this.AnimateOpacity(this.typeImg6, this.typeImg6.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.useless4, "Foreground", this.useless4.Foreground.ToString(), "Titles", 0.2);
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00006724 File Offset: 0x00004924
		private void aiTextbox_LostFocus(object sender, RoutedEventArgs e)
		{
			MainWindow.AnimateColor(this.aiTextboxBrd, "BorderBrush", this.aiTextboxBrd.BorderBrush.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.aiTextbox, "Foreground", this.aiTextbox.Foreground.ToString(), "Descriptions", 0.2);
			MainWindow.AnimateColor(this.aiTextboxBrd, "Background", this.aiTextboxBrd.Background.ToString(), "LightBackground", 0.2);
			this.AnimateBorderThickness(this.aiTextboxBrd, this.aiTextboxBrd.BorderThickness, new Thickness(0.0, 0.0, 0.0, 1.0), 0.2);
			this.AnimateOpacity(this.typeImg6, this.typeImg6.Opacity, 0.0, 0.2);
			MainWindow.AnimateColor(this.useless4, "Foreground", this.useless4.Foreground.ToString(), "Descriptions", 0.2);
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00006862 File Offset: 0x00004A62
		private void execute_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.executeImg, this.executeImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000094 RID: 148 RVA: 0x0000688F File Offset: 0x00004A8F
		private void execute_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.executeImg, this.executeImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000095 RID: 149 RVA: 0x000068BC File Offset: 0x00004ABC
		private void clear_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clearImg, this.clearImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000068E9 File Offset: 0x00004AE9
		private void clear_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.clearImg, this.clearImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00006916 File Offset: 0x00004B16
		private void open_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.openImg, this.openImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00006943 File Offset: 0x00004B43
		private void open_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.openImg, this.openImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00006970 File Offset: 0x00004B70
		private void save_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.saveImg, this.saveImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x0000699D File Offset: 0x00004B9D
		private void save_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.saveImg, this.saveImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600009B RID: 155 RVA: 0x000069CA File Offset: 0x00004BCA
		private void inject_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.injectImg, this.injectImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600009C RID: 156 RVA: 0x000069F7 File Offset: 0x00004BF7
		private void inject_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.AnimateOpacity(this.injectImg, this.injectImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00006A24 File Offset: 0x00004C24
		private void close_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.isClose;
			if (flag)
			{
				base.Close();
			}
			else
			{
				MessageBoxResult result = System.Windows.MessageBox.Show("Are you sure you want to close?", base.Title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
				bool flag2 = result == MessageBoxResult.Yes;
				if (flag2)
				{
					this.isClose = true;
					base.Close();
				}
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00006A7C File Offset: 0x00004C7C
		private void maximize_Click(object sender, RoutedEventArgs e)
		{
			bool flag = base.WindowState == WindowState.Normal;
			if (flag)
			{
				base.WindowState = WindowState.Maximized;
				this.AnimateOpacity(this.maximizeImg, this.maximizeImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 0.0, 0.2);
				this.AnimateOpacity(this.normalImg, this.normalImg.Opacity, 1.0, 0.2);
				this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 0.0, 0.2);
			}
			else
			{
				bool flag2 = base.WindowState == WindowState.Maximized;
				if (flag2)
				{
					MainWindow.SendMessage(this.hWnd, 274, new IntPtr(61728), IntPtr.Zero);
					this.AnimateOpacity(this.maximizeImg, this.maximizeImg.Opacity, 1.0, 0.2);
					this.AnimateOpacity(this.maximizedImg, this.maximizedImg.Opacity, 0.0, 0.2);
					this.AnimateOpacity(this.normalImg, this.normalImg.Opacity, 0.0, 0.2);
					this.AnimateOpacity(this.normaledImg, this.normaledImg.Opacity, 0.0, 0.2);
				}
			}
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00006C2B File Offset: 0x00004E2B
		private void minimize_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00006C38 File Offset: 0x00004E38
		private void workspaceSearch_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			bool flag = button != null;
			if (flag)
			{
				bool flag2 = !this.searchScripts;
				if (flag2)
				{
					this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 0.0, 0.3);
					this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 0.0, 0.3);
					this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 1.0, 0.3);
					this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 0.0, 0.3);
					this.workspaceSearchBrd.Visibility = Visibility.Visible;
					this.AnimateOpacity(this.workspaceSearchBrd, this.workspaceSearchBrd.Opacity, 1.0, 0.3);
					this.AnimateHeight(this.workspaceSearchBrd, this.workspaceSearchBrd.Height, 30.0, 0.3);
					this.searchScripts = true;
				}
				else
				{
					button.IsHitTestVisible = false;
					Storyboard storyboard = new Storyboard();
					DoubleAnimation opacityAnimation = new DoubleAnimation
					{
						From = new double?(this.workspaceSearchBrd.Opacity),
						To = new double?(0.0),
						Duration = TimeSpan.FromSeconds(0.3),
						EasingFunction = new CubicEase
						{
							EasingMode = EasingMode.EaseInOut
						}
					};
					Storyboard.SetTarget(opacityAnimation, this.workspaceSearchBrd);
					Storyboard.SetTargetProperty(opacityAnimation, new PropertyPath("Opacity", Array.Empty<object>()));
					storyboard.Children.Add(opacityAnimation);
					storyboard.Completed += delegate(object _, EventArgs __)
					{
						this.workspaceSearchBrd.Visibility = Visibility.Collapsed;
						button.IsHitTestVisible = true;
					};
					this.AnimateOpacity(this.searchImg, this.searchImg.Opacity, 1.0, 0.3);
					this.AnimateOpacity(this.searchedImg, this.searchedImg.Opacity, 0.0, 0.3);
					this.AnimateOpacity(this.cancelSearchImg, this.cancelSearchImg.Opacity, 0.0, 0.3);
					this.AnimateOpacity(this.canceledSearchImg, this.canceledSearchImg.Opacity, 0.0, 0.3);
					storyboard.Begin();
					this.AnimateHeight(this.workspaceSearchBrd, this.workspaceSearchBrd.Height, 0.0, 0.3);
					this.UpdateSearch("");
					this.searchScripts = false;
				}
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00006F40 File Offset: 0x00005140
		private void workspaceMore_Click(object sender, RoutedEventArgs e)
		{
			this.searchScripts = !this.searchScripts;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00006F54 File Offset: 0x00005154
		private void TreeViewItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			TreeViewItem treeViewItem = sender as TreeViewItem;
			bool flag = treeViewItem != null;
			if (flag)
			{
				FileSystemItem item = treeViewItem.DataContext as FileSystemItem;
				bool flag2 = item == null;
				if (!flag2)
				{
					bool flag3 = !treeViewItem.IsSelected;
					if (flag3)
					{
						treeViewItem.IsSelected = true;
					}
					else
					{
						bool isFolder = item.IsFolder;
						if (isFolder)
						{
							treeViewItem.IsExpanded = !treeViewItem.IsExpanded;
						}
						else
						{
							try
							{
								bool flag4 = File.Exists(item.FullPath);
								if (flag4)
								{
									string content = File.ReadAllText(item.FullPath);
									this.webb.ExecuteScriptAsync("setText(\"" + HttpUtility.JavaScriptStringEncode(content) + "\")");
								}
								else
								{
									System.Windows.MessageBox.Show("File not found or access denied.");
								}
							}
							catch (UnauthorizedAccessException)
							{
								System.Windows.MessageBox.Show("Access denied.");
							}
							catch (Exception ex)
							{
								System.Windows.MessageBox.Show("Failed to read " + item.Name + ": " + ex.Message);
							}
						}
						e.Handled = true;
					}
				}
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x00007084 File Offset: 0x00005284
		private void TreeViewItem_Expanded(object sender, RoutedEventArgs e)
		{
			TreeViewItem treeViewItem = sender as TreeViewItem;
			bool flag = treeViewItem != null;
			if (flag)
			{
				FileSystemItem item = treeViewItem.DataContext as FileSystemItem;
				bool flag2 = item != null && item.IsFolder && !item.HasLoadedChildren;
				if (flag2)
				{
					Handler.PopulateChildren(item, new string[]
					{
						"*.cloudy",
						"*.lua",
						"*.luau",
						"*.txt"
					});
				}
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x000070FC File Offset: 0x000052FC
		[DebuggerStepThrough]
		private void Sexecute_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<Sexecute_Click>d__169 <Sexecute_Click>d__ = new MainWindow.<Sexecute_Click>d__169();
			<Sexecute_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Sexecute_Click>d__.<>4__this = this;
			<Sexecute_Click>d__.sender = sender;
			<Sexecute_Click>d__.e = e;
			<Sexecute_Click>d__.<>1__state = -1;
			<Sexecute_Click>d__.<>t__builder.Start<MainWindow.<Sexecute_Click>d__169>(ref <Sexecute_Click>d__);
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00007143 File Offset: 0x00005343
		private void Scopy_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Clipboard.SetText(this.uncScript);
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00007154 File Offset: 0x00005354
		private void Ssave_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !Directory.Exists(this.scriptsFolder);
			if (flag)
			{
				Directory.CreateDirectory(this.scriptsFolder);
				this.Notification("Created " + this.scriptsFolder + ".", 5);
			}
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				Filter = "Featured (*.cloudy;*.lua;*.luau;*.txt)|*.cloudy;*.lua;*.luau;*.txt|All files|*.*",
				Title = "Save script",
				DefaultExt = "cloudy, txt, lua, luau",
				InitialDirectory = this.scriptsFolder
			};
			bool valueOrDefault = saveFileDialog.ShowDialog().GetValueOrDefault();
			if (valueOrDefault)
			{
				try
				{
					File.WriteAllText(saveFileDialog.FileName, this.uncScript);
				}
				catch (Exception ex)
				{
					this.Notification(ex.Message, 10);
				}
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00007228 File Offset: 0x00005428
		private void Sopen_Click(object sender, RoutedEventArgs e)
		{
			this.execution_Click(null, null);
			this.webb.ExecuteScriptAsyncWhenPageLoaded(string.Concat(new string[]
			{
				"addTab(\"",
				HttpUtility.JavaScriptStringEncode("Unified Naming Convention (UNC test)"),
				"\", \"",
				HttpUtility.JavaScriptStringEncode(this.uncScript),
				"\")"
			}), true);
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0000728C File Offset: 0x0000548C
		[DebuggerStepThrough]
		private void Sexecute2_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<Sexecute2_Click>d__173 <Sexecute2_Click>d__ = new MainWindow.<Sexecute2_Click>d__173();
			<Sexecute2_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Sexecute2_Click>d__.<>4__this = this;
			<Sexecute2_Click>d__.sender = sender;
			<Sexecute2_Click>d__.e = e;
			<Sexecute2_Click>d__.<>1__state = -1;
			<Sexecute2_Click>d__.<>t__builder.Start<MainWindow.<Sexecute2_Click>d__173>(ref <Sexecute2_Click>d__);
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x000072D3 File Offset: 0x000054D3
		private void Scopy2_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Clipboard.SetText(this.sUncScript);
		}

		// Token: 0x060000AA RID: 170 RVA: 0x000072E4 File Offset: 0x000054E4
		private void Ssave2_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !Directory.Exists(this.scriptsFolder);
			if (flag)
			{
				Directory.CreateDirectory(this.scriptsFolder);
				this.Notification("Created " + this.scriptsFolder + ".", 5);
			}
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				Filter = "Featured (*.cloudy;*.lua;*.luau;*.txt)|*.cloudy;*.lua;*.luau;*.txt|All files|*.*",
				Title = "Save script",
				DefaultExt = "cloudy, txt, lua, luau",
				InitialDirectory = this.scriptsFolder
			};
			bool valueOrDefault = saveFileDialog.ShowDialog().GetValueOrDefault();
			if (valueOrDefault)
			{
				try
				{
					File.WriteAllText(saveFileDialog.FileName, this.sUncScript);
				}
				catch (Exception ex)
				{
					this.Notification(ex.Message, 10);
				}
			}
		}

		// Token: 0x060000AB RID: 171 RVA: 0x000073B8 File Offset: 0x000055B8
		private void Sopen2_Click(object sender, RoutedEventArgs e)
		{
			this.execution_Click(null, null);
			this.webb.ExecuteScriptAsyncWhenPageLoaded(string.Concat(new string[]
			{
				"addTab(\"",
				HttpUtility.JavaScriptStringEncode("Security User Name Context (sUNC test)"),
				"\", \"",
				HttpUtility.JavaScriptStringEncode(this.sUncScript),
				"\")"
			}), true);
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000741C File Offset: 0x0000561C
		[DebuggerStepThrough]
		private void Sexecute3_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<Sexecute3_Click>d__177 <Sexecute3_Click>d__ = new MainWindow.<Sexecute3_Click>d__177();
			<Sexecute3_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Sexecute3_Click>d__.<>4__this = this;
			<Sexecute3_Click>d__.sender = sender;
			<Sexecute3_Click>d__.e = e;
			<Sexecute3_Click>d__.<>1__state = -1;
			<Sexecute3_Click>d__.<>t__builder.Start<MainWindow.<Sexecute3_Click>d__177>(ref <Sexecute3_Click>d__);
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00007463 File Offset: 0x00005663
		private void Scopy3_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Clipboard.SetText(this.iYScript);
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00007474 File Offset: 0x00005674
		private void Ssave3_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !Directory.Exists(this.scriptsFolder);
			if (flag)
			{
				Directory.CreateDirectory(this.scriptsFolder);
				this.Notification("Created " + this.scriptsFolder + ".", 5);
			}
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				Filter = "Featured (*.cloudy;*.lua;*.luau;*.txt)|*.cloudy;*.lua;*.luau;*.txt|All files|*.*",
				Title = "Save script",
				DefaultExt = "cloudy, txt, lua, luau",
				InitialDirectory = this.scriptsFolder
			};
			bool valueOrDefault = saveFileDialog.ShowDialog().GetValueOrDefault();
			if (valueOrDefault)
			{
				try
				{
					File.WriteAllText(saveFileDialog.FileName, this.iYScript);
				}
				catch (Exception ex)
				{
					this.Notification(ex.Message, 10);
				}
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00007548 File Offset: 0x00005748
		private void Sopen3_Click(object sender, RoutedEventArgs e)
		{
			this.execution_Click(null, null);
			this.webb.ExecuteScriptAsyncWhenPageLoaded(string.Concat(new string[]
			{
				"addTab(\"",
				HttpUtility.JavaScriptStringEncode("Infinite Yield FE v6.2"),
				"\", \"",
				HttpUtility.JavaScriptStringEncode(this.iYScript),
				"\")"
			}), true);
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x000075AC File Offset: 0x000057AC
		[DebuggerStepThrough]
		private void scriptHubNext_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<scriptHubNext_Click>d__181 <scriptHubNext_Click>d__ = new MainWindow.<scriptHubNext_Click>d__181();
			<scriptHubNext_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<scriptHubNext_Click>d__.<>4__this = this;
			<scriptHubNext_Click>d__.sender = sender;
			<scriptHubNext_Click>d__.e = e;
			<scriptHubNext_Click>d__.<>1__state = -1;
			<scriptHubNext_Click>d__.<>t__builder.Start<MainWindow.<scriptHubNext_Click>d__181>(ref <scriptHubNext_Click>d__);
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x000075F4 File Offset: 0x000057F4
		[DebuggerStepThrough]
		private void scriptHubPrevious_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<scriptHubPrevious_Click>d__182 <scriptHubPrevious_Click>d__ = new MainWindow.<scriptHubPrevious_Click>d__182();
			<scriptHubPrevious_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<scriptHubPrevious_Click>d__.<>4__this = this;
			<scriptHubPrevious_Click>d__.sender = sender;
			<scriptHubPrevious_Click>d__.e = e;
			<scriptHubPrevious_Click>d__.<>1__state = -1;
			<scriptHubPrevious_Click>d__.<>t__builder.Start<MainWindow.<scriptHubPrevious_Click>d__182>(ref <scriptHubPrevious_Click>d__);
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0000763C File Offset: 0x0000583C
		private void home_Click(object sender, RoutedEventArgs e)
		{
			this.SwitchSection(this.FindCurrentVisibleSection(), this.Home);
			this.AnimateOpacity(this.homeSelectedImg, this.homeSelectedImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.homeText, "Foreground", this.homeText.Foreground.ToString(), "Titles", 0.2);
			this.sideBar_MouseLeave(sender, new System.Windows.Input.MouseEventArgs(Mouse.PrimaryDevice, 0));
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x000076CC File Offset: 0x000058CC
		private void execution_Click(object sender, RoutedEventArgs e)
		{
			this.SwitchSection(this.FindCurrentVisibleSection(), this.Execution);
			this.AnimateOpacity(this.executionSelectedImg, this.executionSelectedImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.executionText, "Foreground", this.executionText.Foreground.ToString(), "Titles", 0.2);
			this.sideBar_MouseLeave(sender, new System.Windows.Input.MouseEventArgs(Mouse.PrimaryDevice, 0));
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0000775C File Offset: 0x0000595C
		private void scripthub_Click(object sender, RoutedEventArgs e)
		{
			this.SwitchSection(this.FindCurrentVisibleSection(), this.Scipthub);
			this.AnimateOpacity(this.hubSelectedImg, this.hubSelectedImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.hubText, "Foreground", this.hubText.Foreground.ToString(), "Titles", 0.2);
			this.sideBar_MouseLeave(sender, new System.Windows.Input.MouseEventArgs(Mouse.PrimaryDevice, 0));
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x000077EC File Offset: 0x000059EC
		private void settings_Click(object sender, RoutedEventArgs e)
		{
			this.SwitchSection(this.FindCurrentVisibleSection(), this.Settings);
			this.AnimateOpacity(this.settingsSelectedImg, this.settingsSelectedImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.settingsText, "Foreground", this.settingsText.Foreground.ToString(), "Titles", 0.2);
			this.sideBar_MouseLeave(sender, new System.Windows.Input.MouseEventArgs(Mouse.PrimaryDevice, 0));
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0000787C File Offset: 0x00005A7C
		private void ai_Click(object sender, RoutedEventArgs e)
		{
			this.SwitchSection(this.FindCurrentVisibleSection(), this.AI);
			this.AnimateOpacity(this.aiSelectedImg, this.aiSelectedImg.Opacity, 1.0, 0.2);
			MainWindow.AnimateColor(this.aiText, "Foreground", this.aiText.Foreground.ToString(), "Titles", 0.2);
			this.sideBar_MouseLeave(sender, new System.Windows.Input.MouseEventArgs(Mouse.PrimaryDevice, 0));
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0000790C File Offset: 0x00005B0C
		private void settingsExecutor_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.settingsVal == "customize";
			if (flag)
			{
				this.SettingsExecutor.Visibility = Visibility.Visible;
				this.AnimatePosition((TranslateTransform)this.SettingsExecutor.RenderTransform, 50.0, 0.0, 0.5);
				this.AnimateOpacity(this.SettingsExecutor, 0.0, 1.0, 0.5);
				this.AnimateOpacity(this.SettingsCustomize, 1.0, 0.0, 0.3);
				this.AnimatePosition((TranslateTransform)this.SettingsCustomize.RenderTransform, 0.0, 50.0, 0.3);
				this.AnimateWidth(this.settingsCustomize, this.settingsCustomize.Width, new double?((double)30), 0.3);
				this.AnimateOpacity(this.settingsCustomizeImg, this.settingsCustomizeImg.Opacity, 0.0, 0.3);
				MainWindow.AnimateColor(this.settingsCustomizeText, "Foreground", this.settingsCustomizeText.Foreground.ToString(), "Descriptions", 0.3);
				this.AnimateOpacity(this.settingsCustomizeSelectedImg, this.settingsCustomizeSelectedImg.Opacity, 0.0, 0.2);
				this.AnimateWidth(this.settingsExecutor, this.settingsExecutor.Width, new double?(75.5), 0.3);
				this.AnimateOpacity(this.settingsExecutorImg, this.settingsExecutorImg.Opacity, 0.0, 0.3);
				MainWindow.AnimateColor(this.settingsExecutorText, "Foreground", this.settingsExecutorText.Foreground.ToString(), "Titles", 0.3);
				this.AnimateOpacity(this.settingsExecutorSelectedImg, this.settingsExecutorSelectedImg.Opacity, 1.0, 0.2);
				this.settingsVal = "executor";
			}
			Storyboard storyboard = new Storyboard();
			storyboard.Completed += delegate(object _, EventArgs __)
			{
				this.SettingsCustomize.Visibility = Visibility.Collapsed;
			};
			storyboard.Begin();
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00007B80 File Offset: 0x00005D80
		private void settingsCustomize_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.settingsVal == "executor";
			if (flag)
			{
				this.SettingsCustomize.Visibility = Visibility.Visible;
				this.AnimatePosition((TranslateTransform)this.SettingsCustomize.RenderTransform, 50.0, 0.0, 0.5);
				this.AnimateOpacity(this.SettingsCustomize, 0.0, 1.0, 0.5);
				this.AnimateOpacity(this.SettingsExecutor, 1.0, 0.0, 0.3);
				this.AnimatePosition((TranslateTransform)this.SettingsExecutor.RenderTransform, 0.0, 50.0, 0.3);
				this.AnimateWidth(this.settingsExecutor, this.settingsExecutor.Width, new double?((double)30), 0.3);
				this.AnimateOpacity(this.settingsExecutorImg, this.settingsExecutorImg.Opacity, 0.0, 0.3);
				MainWindow.AnimateColor(this.settingsExecutorText, "Foreground", this.settingsExecutorText.Foreground.ToString(), "Descriptions", 0.3);
				this.AnimateOpacity(this.settingsExecutorSelectedImg, this.settingsExecutorSelectedImg.Opacity, 0.0, 0.2);
				this.AnimateWidth(this.settingsCustomize, this.settingsCustomize.Width, new double?((double)85), 0.3);
				this.AnimateOpacity(this.settingsCustomizeImg, this.settingsCustomizeImg.Opacity, 0.0, 0.3);
				MainWindow.AnimateColor(this.settingsCustomizeText, "Foreground", this.settingsCustomizeText.Foreground.ToString(), "Titles", 0.3);
				this.AnimateOpacity(this.settingsCustomizeSelectedImg, this.settingsCustomizeSelectedImg.Opacity, 1.0, 0.2);
				this.settingsVal = "customize";
			}
			Storyboard storyboard = new Storyboard();
			storyboard.Completed += delegate(object _, EventArgs __)
			{
				this.SettingsExecutor.Visibility = Visibility.Collapsed;
			};
			storyboard.Begin();
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00007DEB File Offset: 0x00005FEB
		private void fixCloudy_Click(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00007DF0 File Offset: 0x00005FF0
		private void clearLogs_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			bool flag = button != null;
			if (flag)
			{
				button.IsEnabled = false;
				this.AnimateOpacity(button, button.Opacity, 0.5, 0.2);
			}
			try
			{
				bool flag2 = !Directory.Exists(this.logsFolder);
				if (flag2)
				{
					this.Notification(this.logsFolder + " not found, creating it..", 10);
					Directory.CreateDirectory(this.logsFolder);
				}
				else
				{
					string[] files = Directory.GetFiles(this.logsFolder);
					bool flag3 = files.Length == 0;
					if (flag3)
					{
						this.Notification(this.logsFolder + " is empty.", 5);
					}
					else
					{
						MessageBoxResult confirmation = System.Windows.MessageBox.Show("Are you sure you want to continue?", base.Title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
						bool flag4 = confirmation == MessageBoxResult.No || confirmation == MessageBoxResult.Cancel || confirmation == MessageBoxResult.None;
						if (!flag4)
						{
							foreach (string file in files)
							{
								string extension = Path.GetExtension(file);
								bool flag5 = extension.Equals(".txt", StringComparison.OrdinalIgnoreCase);
								if (flag5)
								{
									try
									{
										File.Delete(file);
									}
									catch (Exception ex)
									{
										this.Notification("Failed to delete " + file + ": " + ex.Message, 10);
									}
								}
								else
								{
									MessageBoxResult result = System.Windows.MessageBox.Show("The file \"" + Path.GetFileName(file) + "\" is not a .txt file. Do you want to delete it?", base.Title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
									bool flag6 = result == MessageBoxResult.Yes;
									if (flag6)
									{
										try
										{
											File.Delete(file);
										}
										catch (Exception ex2)
										{
											this.Notification("Failed to delete " + file + ": " + ex2.Message, 10);
										}
									}
									else
									{
										bool flag7 = result == MessageBoxResult.Cancel;
										if (flag7)
										{
											break;
										}
									}
								}
							}
							this.Notification("Successfully cleared crash logs.", 8);
						}
					}
				}
			}
			finally
			{
				bool flag8 = button != null;
				if (flag8)
				{
					button.IsEnabled = true;
					this.AnimateOpacity(button, button.Opacity, 1.0, 0.2);
				}
			}
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00008060 File Offset: 0x00006260
		private void customizeCloudy_Click(object sender, RoutedEventArgs e)
		{
			this.customizeCloudyBrd.Visibility = Visibility.Visible;
			this.effect.Visibility = Visibility.Visible;
			ScaleTransform scaleTransform = new ScaleTransform(1.0, 1.0);
			this.customizeCloudyBrd.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
			this.customizeCloudyBrd.RenderTransform = scaleTransform;
			DoubleAnimation scaleXAnimation = new DoubleAnimation
			{
				From = new double?(0.5),
				To = new double?((double)1),
				Duration = TimeSpan.FromSeconds(0.2),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseOut
				},
				AutoReverse = false
			};
			DoubleAnimation scaleYAnimation = new DoubleAnimation
			{
				From = new double?(0.5),
				To = new double?((double)1),
				Duration = TimeSpan.FromSeconds(0.2),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseOut
				},
				AutoReverse = false
			};
			scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
			scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);
			this.AnimateOpacity(this.customizeCloudyBrd, this.customizeCloudyBrd.Opacity, 1.0, 0.2);
			this.AnimateOpacity(this.effect, this.effect.Opacity, 0.5, 0.2);
			FocusManager.SetFocusedElement(this, this);
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00008204 File Offset: 0x00006404
		private void moreTitles_Click(object sender, RoutedEventArgs e)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				bool flag = colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					System.Drawing.Color selectedColor = colorDialog.Color;
					this.customTitlesTextbox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", selectedColor.R, selectedColor.G, selectedColor.B);
				}
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00008288 File Offset: 0x00006488
		private void moreDesc_Click(object sender, RoutedEventArgs e)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				bool flag = colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					System.Drawing.Color selectedColor = colorDialog.Color;
					this.customDescTextbox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", selectedColor.R, selectedColor.G, selectedColor.B);
				}
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x0000830C File Offset: 0x0000650C
		private void moreBg_Click(object sender, RoutedEventArgs e)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				bool flag = colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					System.Drawing.Color selectedColor = colorDialog.Color;
					this.customBgTextbox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", selectedColor.R, selectedColor.G, selectedColor.B);
				}
			}
		}

		// Token: 0x060000BF RID: 191 RVA: 0x00008390 File Offset: 0x00006590
		private void moreBrd_Click(object sender, RoutedEventArgs e)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				bool flag = colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					System.Drawing.Color selectedColor = colorDialog.Color;
					this.customBrdTextbox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", selectedColor.R, selectedColor.G, selectedColor.B);
				}
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00008414 File Offset: 0x00006614
		private void moreLBrd_Click(object sender, RoutedEventArgs e)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				bool flag = colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					System.Drawing.Color selectedColor = colorDialog.Color;
					this.customLBrdTextbox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", selectedColor.R, selectedColor.G, selectedColor.B);
				}
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00008498 File Offset: 0x00006698
		private void effect_Click(object sender, RoutedEventArgs e)
		{
			ScaleTransform scaleTransform = new ScaleTransform(1.0, 1.0);
			this.customizeCloudyBrd.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
			this.customizeCloudyBrd.RenderTransform = scaleTransform;
			DoubleAnimation scaleXAnimation = new DoubleAnimation
			{
				From = new double?((double)1),
				To = new double?(0.5),
				Duration = TimeSpan.FromSeconds(0.2),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseIn
				}
			};
			DoubleAnimation scaleYAnimation = new DoubleAnimation
			{
				From = new double?((double)1),
				To = new double?(0.5),
				Duration = TimeSpan.FromSeconds(0.2),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseIn
				}
			};
			DoubleAnimation opacityAnimation = new DoubleAnimation
			{
				From = new double?((double)1),
				To = new double?(0.0),
				Duration = TimeSpan.FromSeconds(0.2),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseIn
				}
			};
			opacityAnimation.Completed += delegate(object s, EventArgs args)
			{
				this.customizeCloudyBrd.Visibility = Visibility.Collapsed;
				this.effect.Visibility = Visibility.Collapsed;
			};
			scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleXAnimation);
			scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleYAnimation);
			this.customizeCloudyBrd.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
			this.AnimateOpacity(this.effect, this.effect.Opacity, 0.0, 0.2);
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000865C File Offset: 0x0000685C
		private void homeScripts_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.OpenCloudyICM();
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x00008668 File Offset: 0x00006868
		private void inject_Click(object sender, RoutedEventArgs e)
		{
			Api.inject();
			this.Notification("Inject", 5);
			MainWindow.AnimateColor(this.statusColor, "Foreground", this.statusColor.Foreground.ToString(), "#90ee90", 0.3);
			this.statusText.Text = "Injected";
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x000086CC File Offset: 0x000068CC
		[DebuggerStepThrough]
		private void execute_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<execute_Click>d__201 <execute_Click>d__ = new MainWindow.<execute_Click>d__201();
			<execute_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<execute_Click>d__.<>4__this = this;
			<execute_Click>d__.sender = sender;
			<execute_Click>d__.e = e;
			<execute_Click>d__.<>1__state = -1;
			<execute_Click>d__.<>t__builder.Start<MainWindow.<execute_Click>d__201>(ref <execute_Click>d__);
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00008713 File Offset: 0x00006913
		private void clear_Click(object sender, RoutedEventArgs e)
		{
			this.webb.ExecuteScriptAsyncWhenPageLoaded("setText('')", true);
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00008728 File Offset: 0x00006928
		private void open_Click(object sender, RoutedEventArgs e)
		{
			Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
			{
				Filter = "Featured (*.cloudy;*.lua;*.luau;*.txt)|*.cloudy;*.lua;*.luau;*.txt|All files|*.*",
				Title = "Open file",
				DefaultExt = "cloudy, txt, lua, luau",
				InitialDirectory = this.scriptsFolder
			};
			bool valueOrDefault = openFileDialog.ShowDialog().GetValueOrDefault();
			if (valueOrDefault)
			{
				try
				{
					string content = File.ReadAllText(openFileDialog.FileName);
					this.webb.ExecuteScriptAsyncWhenPageLoaded("setText(\"" + HttpUtility.JavaScriptStringEncode(content) + "\")", true);
				}
				catch (Exception nigger)
				{
					this.Notification("Failed to read file: " + nigger.Message, 8);
				}
			}
			else
			{
				this.Notification("An unexpected error occurred.", 5);
			}
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000087F4 File Offset: 0x000069F4
		[DebuggerStepThrough]
		private void save_Click(object sender, RoutedEventArgs e)
		{
			MainWindow.<save_Click>d__204 <save_Click>d__ = new MainWindow.<save_Click>d__204();
			<save_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<save_Click>d__.<>4__this = this;
			<save_Click>d__.sender = sender;
			<save_Click>d__.e = e;
			<save_Click>d__.<>1__state = -1;
			<save_Click>d__.<>t__builder.Start<MainWindow.<save_Click>d__204>(ref <save_Click>d__);
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000883C File Offset: 0x00006A3C
		private void workspaceTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = this.workspaceTextbox.Text.Length > 0;
			if (flag)
			{
				this.useless.Text = "";
				this.UpdateSearch(this.workspaceTextbox.Text);
			}
			else
			{
				this.useless.Text = "Search...";
				this.Refresh(null, null);
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x000088A4 File Offset: 0x00006AA4
		private void scriptHubTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = this.scriptHubTextbox.Text.Length > 0;
			if (flag)
			{
				this.useless2.Text = "";
			}
			else
			{
				this.useless2.Text = "Search...";
				this.scripthubTitle.Text = "Featured";
				this.featured.Visibility = Visibility.Visible;
				this.scriptHubScrollBar.Visibility = Visibility.Collapsed;
				this.scriptBlox.Children.Clear();
				this.scriptHubNext.IsEnabled = false;
				this.scriptHubPrevious.IsEnabled = false;
				this.AnimateOpacity(this.scriptHubNext, this.scriptHubNext.Opacity, 0.5, 0.2);
				this.AnimateOpacity(this.scriptHubPrevious, this.scriptHubPrevious.Opacity, 0.5, 0.2);
			}
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000089A0 File Offset: 0x00006BA0
		[DebuggerStepThrough]
		private void scriptHubTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			MainWindow.<scriptHubTextbox_KeyDown>d__207 <scriptHubTextbox_KeyDown>d__ = new MainWindow.<scriptHubTextbox_KeyDown>d__207();
			<scriptHubTextbox_KeyDown>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<scriptHubTextbox_KeyDown>d__.<>4__this = this;
			<scriptHubTextbox_KeyDown>d__.sender = sender;
			<scriptHubTextbox_KeyDown>d__.e = e;
			<scriptHubTextbox_KeyDown>d__.<>1__state = -1;
			<scriptHubTextbox_KeyDown>d__.<>t__builder.Start<MainWindow.<scriptHubTextbox_KeyDown>d__207>(ref <scriptHubTextbox_KeyDown>d__);
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000089E8 File Offset: 0x00006BE8
		private void customTitlesTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = !this.customTitlesTextbox.Text.StartsWith("#");
			if (flag)
			{
				this.customTitlesTextbox.Text = "#" + this.customTitlesTextbox.Text.TrimStart(new char[]
				{
					'#'
				});
				this.customTitlesTextbox.CaretIndex = this.customTitlesTextbox.Text.Length;
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00008A64 File Offset: 0x00006C64
		private void customTitlesTextbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			string input = e.Text;
			bool flag = !Regex.IsMatch(input, "^[a-fA-F0-9]$");
			if (flag)
			{
				e.Handled = true;
			}
			else
			{
				bool flag2 = this.customTitlesTextbox.Text.Length >= 7;
				if (flag2)
				{
					e.Handled = true;
				}
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00008ABC File Offset: 0x00006CBC
		private void customTitlesTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string hexColor = this.customTitlesTextbox.Text.Trim();
				bool flag2 = !hexColor.StartsWith("#");
				if (flag2)
				{
					hexColor = "#" + hexColor;
				}
				try
				{
					System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
					this.updateTheme("Titles", hexColor);
				}
				catch (FormatException ex)
				{
					this.Notification("Invalid HEX color code. Must be in the format #RRGGBB. Error: " + ex.Message, 10);
				}
			}
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00008B58 File Offset: 0x00006D58
		private void customDescTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = !this.customDescTextbox.Text.StartsWith("#");
			if (flag)
			{
				this.customDescTextbox.Text = "#" + this.customDescTextbox.Text.TrimStart(new char[]
				{
					'#'
				});
				this.customDescTextbox.CaretIndex = this.customDescTextbox.Text.Length;
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00008BD4 File Offset: 0x00006DD4
		private void customDescTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string hexColor = this.customDescTextbox.Text.Trim();
				bool flag2 = !hexColor.StartsWith("#");
				if (flag2)
				{
					hexColor = "#" + hexColor;
				}
				try
				{
					System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
					this.updateTheme("Descriptions", hexColor);
				}
				catch (FormatException ex)
				{
					this.Notification("Invalid HEX color code. Must be in the format #RRGGBB. Error: " + ex.Message, 10);
				}
			}
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00008C70 File Offset: 0x00006E70
		private void customDescTextbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			string input = e.Text;
			bool flag = !Regex.IsMatch(input, "^[a-fA-F0-9]$");
			if (flag)
			{
				e.Handled = true;
			}
			else
			{
				bool flag2 = this.customDescTextbox.Text.Length >= 7;
				if (flag2)
				{
					e.Handled = true;
				}
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00008CC8 File Offset: 0x00006EC8
		private void customBgTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = !this.customBgTextbox.Text.StartsWith("#");
			if (flag)
			{
				this.customBgTextbox.Text = "#" + this.customBgTextbox.Text.TrimStart(new char[]
				{
					'#'
				});
				this.customBgTextbox.CaretIndex = this.customBgTextbox.Text.Length;
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00008D44 File Offset: 0x00006F44
		private void customBgTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string hexColor = this.customBgTextbox.Text.Trim();
				bool flag2 = !hexColor.StartsWith("#");
				if (flag2)
				{
					hexColor = "#" + hexColor;
				}
				try
				{
					System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
					this.updateTheme("Background", hexColor);
				}
				catch (FormatException ex)
				{
					this.Notification("Invalid HEX color code. Must be in the format #RRGGBB. Error: " + ex.Message, 10);
				}
			}
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00008DE0 File Offset: 0x00006FE0
		private void customBgTextbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			string input = e.Text;
			bool flag = !Regex.IsMatch(input, "^[a-fA-F0-9]$");
			if (flag)
			{
				e.Handled = true;
			}
			else
			{
				bool flag2 = this.customBgTextbox.Text.Length >= 7;
				if (flag2)
				{
					e.Handled = true;
				}
			}
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00008E38 File Offset: 0x00007038
		private void customBrdTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = !this.customBrdTextbox.Text.StartsWith("#");
			if (flag)
			{
				this.customBrdTextbox.Text = "#" + this.customBrdTextbox.Text.TrimStart(new char[]
				{
					'#'
				});
				this.customBrdTextbox.CaretIndex = this.customBrdTextbox.Text.Length;
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00008EB4 File Offset: 0x000070B4
		private void customBrdTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string hexColor = this.customBrdTextbox.Text.Trim();
				bool flag2 = !hexColor.StartsWith("#");
				if (flag2)
				{
					hexColor = "#" + hexColor;
				}
				try
				{
					System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
					this.updateTheme("LightBackground", hexColor);
				}
				catch (FormatException ex)
				{
					this.Notification("Invalid HEX color code. Must be in the format #RRGGBB. Error: " + ex.Message, 10);
				}
			}
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00008F50 File Offset: 0x00007150
		private void customBrdTextbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			string input = e.Text;
			bool flag = !Regex.IsMatch(input, "^[a-fA-F0-9]$");
			if (flag)
			{
				e.Handled = true;
			}
			else
			{
				bool flag2 = this.customBrdTextbox.Text.Length >= 7;
				if (flag2)
				{
					e.Handled = true;
				}
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00008FA8 File Offset: 0x000071A8
		private void customLBrdTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = !this.customLBrdTextbox.Text.StartsWith("#");
			if (flag)
			{
				this.customLBrdTextbox.Text = "#" + this.customLBrdTextbox.Text.TrimStart(new char[]
				{
					'#'
				});
				this.customLBrdTextbox.CaretIndex = this.customLBrdTextbox.Text.Length;
			}
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00009024 File Offset: 0x00007224
		private void customLBrdTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string hexColor = this.customLBrdTextbox.Text.Trim();
				bool flag2 = !hexColor.StartsWith("#");
				if (flag2)
				{
					hexColor = "#" + hexColor;
				}
				try
				{
					System.Windows.Media.Color color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
					this.updateTheme("Border", hexColor);
				}
				catch (FormatException ex)
				{
					this.Notification("Invalid HEX color code. Must be in the format #RRGGBB. Error: " + ex.Message, 10);
				}
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x000090C0 File Offset: 0x000072C0
		private void customLBrdTextbox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			string input = e.Text;
			bool flag = !Regex.IsMatch(input, "^[a-fA-F0-9]$");
			if (flag)
			{
				e.Handled = true;
			}
			else
			{
				bool flag2 = this.customLBrdTextbox.Text.Length >= 7;
				if (flag2)
				{
					e.Handled = true;
				}
			}
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00009118 File Offset: 0x00007318
		private void aiTextbox_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool flag = this.aiTextbox.Text.Length > 0;
			if (flag)
			{
				this.useless4.Text = "";
			}
			else
			{
				this.useless4.Text = "Request...";
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00009168 File Offset: 0x00007368
		[DebuggerStepThrough]
		private void aiTextbox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			MainWindow.<aiTextbox_KeyDown>d__224 <aiTextbox_KeyDown>d__ = new MainWindow.<aiTextbox_KeyDown>d__224();
			<aiTextbox_KeyDown>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<aiTextbox_KeyDown>d__.<>4__this = this;
			<aiTextbox_KeyDown>d__.sender = sender;
			<aiTextbox_KeyDown>d__.e = e;
			<aiTextbox_KeyDown>d__.<>1__state = -1;
			<aiTextbox_KeyDown>d__.<>t__builder.Start<MainWindow.<aiTextbox_KeyDown>d__224>(ref <aiTextbox_KeyDown>d__);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x000091AF File Offset: 0x000073AF
		private void crashLogs_Checked(object sender, RoutedEventArgs e)
		{
			this.openLogs = true;
		}

		// Token: 0x060000DD RID: 221 RVA: 0x000091BA File Offset: 0x000073BA
		private void crashLogs_Unchecked(object sender, RoutedEventArgs e)
		{
			this.openLogs = false;
		}

		// Token: 0x060000DE RID: 222 RVA: 0x000091C5 File Offset: 0x000073C5
		private void topMost_Checked(object sender, RoutedEventArgs e)
		{
			base.Topmost = true;
		}

		// Token: 0x060000DF RID: 223 RVA: 0x000091D0 File Offset: 0x000073D0
		private void topMost_Unchecked(object sender, RoutedEventArgs e)
		{
			base.Topmost = false;
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0000AF0C File Offset: 0x0000910C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 39)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = System.Windows.Controls.Control.MouseDoubleClickEvent;
				eventSetter.Handler = new MouseButtonEventHandler(this.TreeViewItem_MouseDoubleClick);
				((Style)target).Setters.Add(eventSetter);
				eventSetter = new EventSetter();
				eventSetter.Event = TreeViewItem.ExpandedEvent;
				eventSetter.Handler = new RoutedEventHandler(this.TreeViewItem_Expanded);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x04000009 RID: 9
		private static readonly HttpClient httpClient = new HttpClient();

		// Token: 0x0400000A RID: 10
		private Handler listBoxHandler;

		// Token: 0x0400000B RID: 11
		private FileSystemWatcher fileWatcher;

		// Token: 0x0400000C RID: 12
		private DispatcherTimer refreshTimer;

		// Token: 0x0400000D RID: 13
		private const string RegistryKeyPath = "SOFTWARE\\Cloudy";

		// Token: 0x0400000E RID: 14
		private const string FirstRunValueName = "IsFirstRun";

		// Token: 0x0400000F RID: 15
		public string scriptsFolder = Path.Combine(Directory.GetCurrentDirectory(), "scripts");

		// Token: 0x04000010 RID: 16
		public string binFolder = Path.Combine(Directory.GetCurrentDirectory(), "bin");

		// Token: 0x04000011 RID: 17
		public string logsFolder = Path.Combine(Directory.GetCurrentDirectory(), "logs");

		// Token: 0x04000012 RID: 18
		public bool isClose = false;

		// Token: 0x04000013 RID: 19
		private bool searchScripts = false;

		// Token: 0x04000014 RID: 20
		public bool filesChanged = false;

		// Token: 0x04000015 RID: 21
		private int pageNum = 1;

		// Token: 0x04000016 RID: 22
		private bool isLoaded = false;

		// Token: 0x04000017 RID: 23
		private int totalPages = 1;

		// Token: 0x04000019 RID: 25
		public string settingsVal = "executor";

		// Token: 0x0400001A RID: 26
		private string uncScript = "loadstring(game:HttpGet('https://github.com/ltseverydayyou/uuuuuuu/blob/main/UNC%20test?raw=true'))()";

		// Token: 0x0400001B RID: 27
		private string sUncScript = "loadstring(game:HttpGet(\"https://gitlab.com/sens3/nebunu/-/raw/main/HummingBird8's_sUNC_yes_i_moved_to_gitlab_because_my_github_acc_got_brickedd/sUNCm0m3n7.lua\"))()";

		// Token: 0x0400001C RID: 28
		private string iYScript = "loadstring(game:HttpGet(\"https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source\"))()";

		// Token: 0x0400001D RID: 29
		private IntPtr hWnd;
	}
}
