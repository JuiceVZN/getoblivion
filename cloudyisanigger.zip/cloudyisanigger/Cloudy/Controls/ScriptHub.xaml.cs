﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using CloudyApi;

namespace Cloudy.Controls
{
	// Token: 0x02000009 RID: 9
	public partial class ScriptHub : UserControl
	{
		// Token: 0x06000103 RID: 259 RVA: 0x0000B720 File Offset: 0x00009920
		public ScriptHub()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000B746 File Offset: 0x00009946
		private void execute_click(object sender, RoutedEventArgs e)
		{
			Api.execute(this.ToString());
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000B755 File Offset: 0x00009955
		private void execute_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.executeImg, this.executeImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000B787 File Offset: 0x00009987
		private void execute_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.executeImg, this.executeImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000107 RID: 263 RVA: 0x0000B7B9 File Offset: 0x000099B9
		private void copy_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.copyImg, this.copyImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x06000108 RID: 264 RVA: 0x0000B7EB File Offset: 0x000099EB
		private void copy_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.copyImg, this.copyImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x06000109 RID: 265 RVA: 0x0000B81D File Offset: 0x00009A1D
		private void save_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.saveImg, this.saveImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600010A RID: 266 RVA: 0x0000B84F File Offset: 0x00009A4F
		private void save_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.saveImg, this.saveImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600010B RID: 267 RVA: 0x0000B881 File Offset: 0x00009A81
		private void open_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.openImg, this.openImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x0600010C RID: 268 RVA: 0x0000B8B3 File Offset: 0x00009AB3
		private void open_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.openImg, this.openImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600010D RID: 269 RVA: 0x0000B8E5 File Offset: 0x00009AE5
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.effect, this.effect.Opacity, 0.9, 0.2);
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000B917 File Offset: 0x00009B17
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.effect, this.effect.Opacity, 0.0, 0.2);
		}

		// Token: 0x0600010F RID: 271 RVA: 0x0000B949 File Offset: 0x00009B49
		private void execute_Click(object sender, RoutedEventArgs e)
		{
			Api.execute(this.ToString());
		}

		// Token: 0x040000B9 RID: 185
		private MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
	}
}
