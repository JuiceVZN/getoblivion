﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace Cloudy.Controls
{
	// Token: 0x02000008 RID: 8
	public partial class Notifications : UserControl
	{
		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x0000B292 File Offset: 0x00009492
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x0000B29A File Offset: 0x0000949A
		public int Time { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x0000B2A3 File Offset: 0x000094A3
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x0000B2B0 File Offset: 0x000094B0
		public string NotificationText
		{
			get
			{
				return this.Title.Text;
			}
			set
			{
				this.Title.Text = value;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000B2BF File Offset: 0x000094BF
		public Notifications()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000B2E8 File Offset: 0x000094E8
		public void StartNotification()
		{
			base.RenderTransform = new TranslateTransform();
			Storyboard showStoryboard = new Storyboard();
			DoubleAnimation slideIn = new DoubleAnimation
			{
				From = new double?((double)100),
				To = new double?(0.0),
				Duration = TimeSpan.FromMilliseconds(300.0),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseOut
				}
			};
			Storyboard.SetTarget(slideIn, this);
			Storyboard.SetTargetProperty(slideIn, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)", Array.Empty<object>()));
			showStoryboard.Children.Add(slideIn);
			showStoryboard.Begin();
			this.mainWindow.AnimateOpacity(this, 0.0, 0.95, 0.3);
			this._totalTime = TimeSpan.FromSeconds((double)this.Time);
			this._stopwatch = new Stopwatch();
			this._stopwatch.Start();
			this._timer = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(50.0)
			};
			this._timer.Tick += this.Timer_Tick;
			this._timer.Start();
		}

		// Token: 0x060000FA RID: 250 RVA: 0x0000B428 File Offset: 0x00009628
		private void CloseNotification()
		{
			base.RenderTransform = new TranslateTransform();
			Storyboard closeStoryboard = new Storyboard();
			DoubleAnimation slideOut = new DoubleAnimation
			{
				From = new double?(0.0),
				To = new double?((double)100),
				Duration = TimeSpan.FromMilliseconds(400.0),
				EasingFunction = new QuadraticEase
				{
					EasingMode = EasingMode.EaseIn
				}
			};
			Storyboard.SetTarget(slideOut, this);
			Storyboard.SetTargetProperty(slideOut, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)", Array.Empty<object>()));
			closeStoryboard.Children.Add(slideOut);
			closeStoryboard.Completed += delegate(object s, EventArgs e)
			{
				base.Dispatcher.InvokeAsync(delegate()
				{
					Panel parent = base.Parent as Panel;
					if (parent != null)
					{
						parent.Children.Remove(this);
					}
				}, DispatcherPriority.ApplicationIdle);
			};
			closeStoryboard.Begin();
			this.mainWindow.AnimateOpacity(this, base.Opacity, 0.0, 0.3);
		}

		// Token: 0x060000FB RID: 251 RVA: 0x0000B50C File Offset: 0x0000970C
		private void Timer_Tick(object sender, EventArgs e)
		{
			TimeSpan elapsed = this._stopwatch.Elapsed;
			bool flag = elapsed >= this._totalTime;
			if (flag)
			{
				this._timer.Stop();
				this.CloseNotification();
			}
			else
			{
				double progressPercentage = elapsed.TotalSeconds / this._totalTime.TotalSeconds;
			}
		}

		// Token: 0x060000FC RID: 252 RVA: 0x0000B563 File Offset: 0x00009763
		private void Cancel_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.closedImg, this.closedImg.Opacity, 1.0, 0.2);
		}

		// Token: 0x060000FD RID: 253 RVA: 0x0000B595 File Offset: 0x00009795
		private void Cancel_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mainWindow.AnimateOpacity(this.closedImg, this.closedImg.Opacity, 0.0, 0.2);
		}

		// Token: 0x060000FE RID: 254 RVA: 0x0000B5C7 File Offset: 0x000097C7
		private void Cancel_Click(object sender, RoutedEventArgs e)
		{
			this.CloseNotification();
		}

		// Token: 0x040000AE RID: 174
		private MainWindow mainWindow = Application.Current.MainWindow as MainWindow;

		// Token: 0x040000AF RID: 175
		private DispatcherTimer _timer;

		// Token: 0x040000B0 RID: 176
		private Stopwatch _stopwatch;

		// Token: 0x040000B1 RID: 177
		private TimeSpan _totalTime;
	}
}
