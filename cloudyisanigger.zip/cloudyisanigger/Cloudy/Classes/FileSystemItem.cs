﻿using System;
using System.Collections.ObjectModel;

namespace Cloudy.Classes
{
	// Token: 0x0200000B RID: 11
	public class FileSystemItem
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600011F RID: 287 RVA: 0x0000BDD3 File Offset: 0x00009FD3
		// (set) Token: 0x06000120 RID: 288 RVA: 0x0000BDDB File Offset: 0x00009FDB
		public string Name { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000121 RID: 289 RVA: 0x0000BDE4 File Offset: 0x00009FE4
		// (set) Token: 0x06000122 RID: 290 RVA: 0x0000BDEC File Offset: 0x00009FEC
		public string FullPath { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000123 RID: 291 RVA: 0x0000BDF5 File Offset: 0x00009FF5
		// (set) Token: 0x06000124 RID: 292 RVA: 0x0000BDFD File Offset: 0x00009FFD
		public bool IsFolder { get; set; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000125 RID: 293 RVA: 0x0000BE06 File Offset: 0x0000A006
		// (set) Token: 0x06000126 RID: 294 RVA: 0x0000BE0E File Offset: 0x0000A00E
		public ObservableCollection<FileSystemItem> Children { get; set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000127 RID: 295 RVA: 0x0000BE17 File Offset: 0x0000A017
		// (set) Token: 0x06000128 RID: 296 RVA: 0x0000BE1F File Offset: 0x0000A01F
		public bool HasLoadedChildren { get; set; } = false;

		// Token: 0x06000129 RID: 297 RVA: 0x0000BE28 File Offset: 0x0000A028
		public FileSystemItem()
		{
			this.Children = new ObservableCollection<FileSystemItem>();
		}
	}
}
