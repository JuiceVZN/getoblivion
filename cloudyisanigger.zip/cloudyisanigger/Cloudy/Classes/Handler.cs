﻿using System;
using System.IO;
using System.Windows.Controls;

namespace Cloudy.Classes
{
	// Token: 0x0200000C RID: 12
	internal class Handler
	{
		// Token: 0x0600012A RID: 298 RVA: 0x0000BE48 File Offset: 0x0000A048
		public static void PopulateTreeView(TreeView treeView, string folderPath, string[] fileTypes)
		{
			DirectoryInfo dinfo = new DirectoryInfo(folderPath);
			DirectoryInfo[] directories = dinfo.GetDirectories();
			foreach (DirectoryInfo dir in directories)
			{
				FileSystemItem folderItem = new FileSystemItem
				{
					Name = dir.Name,
					FullPath = dir.FullName,
					IsFolder = true
				};
				folderItem.Children.Add(null);
				treeView.Items.Add(folderItem);
			}
			foreach (string fileType in fileTypes)
			{
				FileInfo[] files = dinfo.GetFiles(fileType);
				foreach (FileInfo file in files)
				{
					FileSystemItem fileItem = new FileSystemItem
					{
						Name = file.Name,
						FullPath = file.FullName,
						IsFolder = false
					};
					treeView.Items.Add(fileItem);
				}
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000BF48 File Offset: 0x0000A148
		public static void PopulateChildren(FileSystemItem folderItem, string[] fileTypes)
		{
			bool hasLoadedChildren = folderItem.HasLoadedChildren;
			if (!hasLoadedChildren)
			{
				folderItem.Children.Clear();
				DirectoryInfo dinfo = new DirectoryInfo(folderItem.FullPath);
				DirectoryInfo[] directories = dinfo.GetDirectories();
				foreach (DirectoryInfo dir in directories)
				{
					FileSystemItem subFolder = new FileSystemItem
					{
						Name = dir.Name,
						FullPath = dir.FullName,
						IsFolder = true
					};
					subFolder.Children.Add(null);
					folderItem.Children.Add(subFolder);
				}
				foreach (string fileType in fileTypes)
				{
					FileInfo[] files = dinfo.GetFiles(fileType);
					foreach (FileInfo file in files)
					{
						FileSystemItem fileItem = new FileSystemItem
						{
							Name = file.Name,
							FullPath = file.FullName,
							IsFolder = false
						};
						folderItem.Children.Add(fileItem);
					}
				}
				folderItem.HasLoadedChildren = true;
			}
		}
	}
}
