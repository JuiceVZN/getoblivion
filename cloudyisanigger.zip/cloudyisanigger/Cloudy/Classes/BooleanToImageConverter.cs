﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace Cloudy.Classes
{
	// Token: 0x0200000A RID: 10
	public class BooleanToImageConverter : IMultiValueConverter
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000112 RID: 274 RVA: 0x0000BC11 File Offset: 0x00009E11
		// (set) Token: 0x06000113 RID: 275 RVA: 0x0000BC19 File Offset: 0x00009E19
		public BitmapImage FolderImage { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000114 RID: 276 RVA: 0x0000BC22 File Offset: 0x00009E22
		// (set) Token: 0x06000115 RID: 277 RVA: 0x0000BC2A File Offset: 0x00009E2A
		public BitmapImage FileImage { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0000BC33 File Offset: 0x00009E33
		// (set) Token: 0x06000117 RID: 279 RVA: 0x0000BC3B File Offset: 0x00009E3B
		public BitmapImage FolderHoverImage { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0000BC44 File Offset: 0x00009E44
		// (set) Token: 0x06000119 RID: 281 RVA: 0x0000BC4C File Offset: 0x00009E4C
		public BitmapImage FolderExpandedHoverImage { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600011A RID: 282 RVA: 0x0000BC55 File Offset: 0x00009E55
		// (set) Token: 0x0600011B RID: 283 RVA: 0x0000BC5D File Offset: 0x00009E5D
		public BitmapImage FileHoverImage { get; set; }

		// Token: 0x0600011C RID: 284 RVA: 0x0000BC68 File Offset: 0x00009E68
		public BooleanToImageConverter()
		{
			try
			{
				this.FolderImage = new BitmapImage(new Uri("pack://application:,,,/Images/folder.png"));
				this.FileImage = new BitmapImage(new Uri("pack://application:,,,/Images/file.png"));
				this.FolderHoverImage = new BitmapImage(new Uri("pack://application:,,,/Images/foldered.png"));
				this.FolderExpandedHoverImage = new BitmapImage(new Uri("pack://application:,,,/Images/opened.png"));
				this.FileHoverImage = new BitmapImage(new Uri("pack://application:,,,/Images/filed.png"));
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading images: " + ex.Message);
			}
		}

		// Token: 0x0600011D RID: 285 RVA: 0x0000BD1C File Offset: 0x00009F1C
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			bool flag = values.Length != 4;
			object result;
			if (flag)
			{
				result = new BitmapImage(new Uri("pack://application:,,,/Images/file.png"));
			}
			else
			{
				bool isFolder = (bool)values[0];
				bool isExpanded = (bool)values[1];
				bool isHovered = (bool)values[2];
				bool isChildHovered = (bool)values[3];
				bool isAnyHovered = isHovered || isChildHovered;
				bool flag2 = isAnyHovered;
				string imagePath;
				if (flag2)
				{
					imagePath = (isFolder ? (isExpanded ? "pack://application:,,,/Images/opened.png" : "pack://application:,,,/Images/foldered.png") : "pack://application:,,,/Images/filed.png");
				}
				else
				{
					imagePath = (isFolder ? (isExpanded ? "pack://application:,,,/Images/open.png" : "pack://application:,,,/Images/folder.png") : "pack://application:,,,/Images/file.png");
				}
				result = new BitmapImage(new Uri(imagePath));
			}
			return result;
		}

		// Token: 0x0600011E RID: 286 RVA: 0x0000BDCB File Offset: 0x00009FCB
		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
