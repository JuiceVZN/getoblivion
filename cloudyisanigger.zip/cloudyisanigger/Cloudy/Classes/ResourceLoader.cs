﻿using System;
using System.IO;
using System.Reflection;

namespace Cloudy.Classes
{
	// Token: 0x0200000D RID: 13
	public static class ResourceLoader
	{
		// Token: 0x0600012D RID: 301 RVA: 0x0000C080 File Offset: 0x0000A280
		public static string LoadResource(string fileName)
		{
			Assembly assembly = Assembly.GetExecutingAssembly();
			string resourceName = "Cloudy.Resources." + fileName;
			string result;
			using (Stream stream = assembly.GetManifestResourceStream(resourceName))
			{
				bool flag = stream == null;
				if (flag)
				{
					throw new Exception("Resource not found: " + resourceName);
				}
				using (StreamReader reader = new StreamReader(stream))
				{
					result = reader.ReadToEnd();
				}
			}
			return result;
		}
	}
}
