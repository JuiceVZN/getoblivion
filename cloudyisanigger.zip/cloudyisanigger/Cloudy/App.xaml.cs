﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using CefSharp;
using CefSharp.Wpf;

namespace Cloudy
{
	// Token: 0x02000003 RID: 3
	public partial class App : Application
	{
		// Token: 0x06000007 RID: 7 RVA: 0x000020EC File Offset: 0x000002EC
		protected override void OnStartup(StartupEventArgs e)
		{
			bool flag = !Directory.Exists(this.logsFolder);
			if (flag)
			{
				Directory.CreateDirectory(this.logsFolder);
			}
			bool flag2 = !Directory.Exists(this.scriptsFolder);
			if (flag2)
			{
				Directory.CreateDirectory(this.scriptsFolder);
			}
			bool flag3 = !Directory.Exists(this.binFolder);
			if (flag3)
			{
				Directory.CreateDirectory(this.binFolder);
			}
			base.OnStartup(e);
			Cef.Initialize(new CefSettings
			{
				CefCommandLineArgs = 
				{
					{
						"allow-file-access-from-files",
						"1"
					},
					{
						"disable-dev-tools",
						"1"
					},
					{
						"disable-print-preview",
						"1"
					},
					{
						"disable-gpu-vsync",
						"1"
					},
					{
						"disable-remote-fonts",
						"1"
					}
				}
			});
			AppDomain.CurrentDomain.UnhandledException += this.OnUnhandledException;
			base.DispatcherUnhandledException += this.OnDispatcherUnhandledException;
			bool isNewInstance;
			App._mutex = new Mutex(true, "Cloudy", ref isNewInstance);
			bool flag4 = !isNewInstance;
			if (flag4)
			{
				MessageBox.Show("Cloudy is already running.", "Cloudy", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				Environment.Exit(0);
			}
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002241 File Offset: 0x00000441
		protected override void OnExit(ExitEventArgs e)
		{
			Mutex mutex = App._mutex;
			if (mutex != null)
			{
				mutex.ReleaseMutex();
			}
			base.OnExit(e);
		}

		// Token: 0x06000009 RID: 9 RVA: 0x0000225D File Offset: 0x0000045D
		private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			this.HandleException(e.Exception);
			e.Handled = true;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002278 File Offset: 0x00000478
		private void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception ex = e.ExceptionObject as Exception;
			bool flag = ex != null;
			if (flag)
			{
				this.HandleException(ex);
			}
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000022A4 File Offset: 0x000004A4
		private void HandleException(Exception ex)
		{
			MainWindow mainWindow = new MainWindow();
			bool value = mainWindow.openLogs;
			try
			{
				string logFilePath = Path.Combine(this.logsFolder, string.Format("crash_log_{0:yyyy-MM-dd_HH-mm-ss}.txt", DateTime.Now));
				File.WriteAllText(logFilePath, this.FormatExceptionDetails(ex));
				bool flag = value;
				if (flag)
				{
					bool flag2 = !string.IsNullOrEmpty(logFilePath);
					if (flag2)
					{
						Process.Start(new ProcessStartInfo
						{
							FileName = logFilePath,
							UseShellExecute = true
						});
					}
				}
				MessageBox.Show("An unexpected error occurred:\n" + ex.Message + "\n\nDetails have been saved to:\n" + logFilePath, "Cloudy", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			catch (Exception logEx)
			{
				MessageBox.Show("Critical error: Unable to write crash logs.\n " + logEx.Message, "Cloudy", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			Environment.Exit(1);
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002384 File Offset: 0x00000584
		private string FormatExceptionDetails(Exception ex)
		{
			return string.Concat(new string[]
			{
				"[Exception Details]\n",
				string.Format("Timestamp: {0}\n", DateTime.Now),
				"Message: ",
				ex.Message,
				"\nSource: ",
				ex.Source,
				"\n",
				string.Format("Target Site: {0}\n", ex.TargetSite),
				"Stack Trace:\n",
				ex.StackTrace,
				"\n"
			});
		}

		// Token: 0x04000001 RID: 1
		public string scriptsFolder = Path.Combine(Directory.GetCurrentDirectory(), "scripts");

		// Token: 0x04000002 RID: 2
		public string binFolder = Path.Combine(Directory.GetCurrentDirectory(), "bin");

		// Token: 0x04000003 RID: 3
		public string logsFolder = Path.Combine(Directory.GetCurrentDirectory(), "logs");

		// Token: 0x04000004 RID: 4
		private static Mutex _mutex;
	}
}
